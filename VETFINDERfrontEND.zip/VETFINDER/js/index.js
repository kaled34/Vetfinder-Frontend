const btnLogin = document.getElementById('btn-login'),
      btnRegister = document.getElementById('btn-register'),
      form = document.getElementById('auth-form'),
      formFields = document.getElementById('form-fields'),
      message = document.getElementById('message');

let mode = 'login';

/**
 * Obtiene el tipo de usuario seleccionado (tutor o especialista)
 */
function tipoSeleccionado() {
  return document.querySelector('input[name="userType"]:checked').value;
}

/**
 * Actualiza los campos del formulario según el modo (login o registro)
 */
function updateForm() {
  message.hidden = true;
  formFields.innerHTML =
    mode === 'login'
      ? `<input type="text" id="usuario" placeholder="Correo electrónico">
         <input type="password" id="contrasena" placeholder="Contraseña">`
      : `<input type="email" id="correo" placeholder="Correo electrónico" required>`;
}

/**
 * Evento para cambiar a modo login
 */
btnLogin.onclick = () => { 
  mode = 'login'; 
  btnLogin.classList.add('active'); 
  btnRegister.classList.remove('active'); 
  updateForm(); 
};

/**
 * Evento para cambiar a modo registro
 */
btnRegister.onclick = () => { 
  mode = 'register'; 
  btnRegister.classList.add('active'); 
  btnLogin.classList.remove('active'); 
  updateForm(); 
};

/**
 * Manejo del envío del formulario (login o registro)
 */
form.onsubmit = (e) => {
  e.preventDefault();
  message.hidden = true;
  const tipo = tipoSeleccionado();

  // MODO REGISTRO - Redirigir a páginas de registro
  if (mode === 'register') {
    const correo = document.getElementById('correo').value.trim().toLowerCase();
    if (!correo) {
      message.textContent = 'Por favor ingresa tu correo.';
      message.hidden = false;
      return;
    }

    // Guardar info temporalmente y redirigir
    localStorage.setItem('ultimoUsuario', JSON.stringify({ correo, tipo }));
    window.location.href = tipo === 'tutor'
      ? `registro-usuario/tutor.html?email=${encodeURIComponent(correo)}`
      : `registro-especialista/especialista.html?email=${encodeURIComponent(correo)}`;
    return;
  }

  // MODO LOGIN - Validar credenciales
  const usuario = document.getElementById('usuario').value.trim().toLowerCase();
  const contrasena = document.getElementById('contrasena').value.trim();
  
  // Validar campos completos
  if (!usuario || !contrasena) {
    message.textContent = 'Completa todos los campos';
    message.hidden = false;
    return;
  }

  // Buscar datos del usuario en localStorage
  const key = `register-${tipo}-${usuario}`;
  const data = JSON.parse(localStorage.getItem(key));
  
  // CORREGIDO: Verificar tanto 'password' como 'pwd' para compatibilidad
  if (!data || (data.password !== contrasena && data.pwd !== contrasena)) {
    message.textContent = 'Usuario o contraseña incorrectos';
    message.hidden = false;
    return;
  }

  // Login exitoso - guardar sesión y redirigir
  localStorage.setItem('ultimoUsuario', JSON.stringify({ correo: usuario, tipo }));
  
  // Redirigir según tipo de usuario
  window.location.href = tipo === 'tutor'
    ? 'inicio-usuario/inicio.html'
    : 'perfil-especialista/perfil-especialista.html';
};

// Inicializar formulario en modo login
updateForm();