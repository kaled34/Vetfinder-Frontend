// JavaScript para vet-consultorio.html - VERSIÓN CON GRÁFICAS
document.addEventListener("DOMContentLoaded", () => {
  // Obtener el correo del especialista desde la URL
  const params = new URLSearchParams(location.search);
  const correo = params.get("correo");
  
  // Si no hay correo, redirigir al inicio
  if (!correo) {
    alert("No se especificó el veterinario.");
    return location.href = "../inicio-usuario/inicio.html";
  }

  // Cargar datos del especialista desde localStorage
  const datos = JSON.parse(localStorage.getItem(`register-especialista-${correo}`));
  if (!datos) {
    alert("No se encontraron datos del veterinario.");
    return location.href = "../inicio-usuario/inicio.html";
  }

  // Funcionalidad de tabs - ACTUALIZADA PARA INCLUIR GRÁFICAS
  const tabs = document.querySelectorAll(".tab");
  const sections = document.querySelectorAll(".tab-content");
  
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      // Remover clase active de todos los tabs y secciones
      tabs.forEach(t => t.classList.remove("active"));
      sections.forEach(s => s.classList.remove("active"));
      
      // Activar el tab clickeado
      tab.classList.add("active");
      
      // Activar la sección correspondiente
      if (tab.id === "tab-consultorio") {
        document.getElementById("consultorio").classList.add("active");
      } else if (tab.id === "tab-datos") {
        document.getElementById("datos").classList.add("active");
        // 🚀 GENERAR GRÁFICAS cuando se abre la pestaña de datos
        generarGraficasEstadisticas(correo);
      } else if (tab.id === "tab-agendar") {
        document.getElementById("agendar").classList.add("active");
        // Regenerar horarios cuando se abre la pestaña de agendar
        generarHorariosDisponibles(datos.horario || "");
      }
    });
  });

  // Llenar campos con datos del especialista
  llenarDatosEspecialista(datos);
  
  // Cargar servicios en la tab de datos
  cargarServiciosLista(datos.servicios || []);
  
  // Cargar servicios en el dropdown de agendar cita
  cargarServiciosDropdown(datos.servicios || []);
  
  // Generar horarios automáticamente al cargar la página
  generarHorariosDisponibles(datos.horario || "");
  
  // Configurar eventos del formulario de cita
  configurarFormularioCita(datos, correo);

  // 🚀 GENERAR GRÁFICAS INICIALES
  generarGraficasEstadisticas(correo);
});

/**
 * 🚀 NUEVA FUNCIÓN: Generar gráficas de estadísticas
 */
function generarGraficasEstadisticas(correoEspecialista) {
  console.log("📊 Generando gráficas para especialista:", correoEspecialista);
  
  // Obtener citas del especialista
  const citas = JSON.parse(localStorage.getItem(`citas-${correoEspecialista}`)) || [];
  
  // Filtrar solo citas aceptadas
  const citasAceptadas = citas.filter(cita => cita.estado === 'aceptada');
  
  console.log("✅ Citas aceptadas encontradas:", citasAceptadas.length);
  
  if (citasAceptadas.length === 0) {
    mostrarGraficasVacias();
    return;
  }
  
  // Procesar datos para las gráficas
  const datosHorarios = procesarDatosHorarios(citasAceptadas);
  const datosServicios = procesarDatosServicios(citasAceptadas);
  
  // Generar las gráficas
  generarGraficaHorarios(datosHorarios);
  generarGraficaServicios(datosServicios);
}

/**
 * 📊 Procesar datos de horarios más concurridos
 */
function procesarDatosHorarios(citasAceptadas) {
  const conteoHorarios = {};
  
  citasAceptadas.forEach(cita => {
    const horario = cita.horario;
    if (horario) {
      // Agrupar por rangos de hora (ejemplo: 09:00-09:59 = "09h")
      const hora = horario.split(':')[0];
      const rango = `${hora}h`;
      
      conteoHorarios[rango] = (conteoHorarios[rango] || 0) + 1;
    }
  });
  
  // Convertir a array y ordenar
  const datosOrdenados = Object.entries(conteoHorarios)
    .map(([horario, cantidad]) => ({ horario, cantidad }))
    .sort((a, b) => {
      // Ordenar por hora
      const horaA = parseInt(a.horario.replace('h', ''));
      const horaB = parseInt(b.horario.replace('h', ''));
      return horaA - horaB;
    });
  
  console.log("⏰ Datos de horarios procesados:", datosOrdenados);
  return datosOrdenados;
}

/**
 * 📊 Procesar datos de servicios más solicitados
 */
function procesarDatosServicios(citasAceptadas) {
  const conteoServicios = {};
  
  citasAceptadas.forEach(cita => {
    const servicio = cita.servicio;
    if (servicio) {
      conteoServicios[servicio] = (conteoServicios[servicio] || 0) + 1;
    }
  });
  
  // Convertir a array y ordenar por cantidad (mayor a menor)
  const datosOrdenados = Object.entries(conteoServicios)
    .map(([servicio, cantidad]) => ({ servicio, cantidad }))
    .sort((a, b) => b.cantidad - a.cantidad)
    .slice(0, 5); // Tomar solo los top 5
  
  console.log("🔬 Datos de servicios procesados:", datosOrdenados);
  return datosOrdenados;
}

/**
 * 📊 Generar gráfica de horarios más concurridos
 */
function generarGraficaHorarios(datosHorarios) {
  // Encontrar el contenedor existente o crearlo
  let container = document.querySelector('.estadisticas-container');
  if (!container) {
    // Crear contenedor si no existe
    container = document.createElement('div');
    container.className = 'estadisticas-container';
    
    // Insertarlo después de los servicios
    const serviciosContainer = document.getElementById('servicios-container');
    if (serviciosContainer && serviciosContainer.parentNode) {
      serviciosContainer.parentNode.appendChild(container);
    }
  }
  
  // Limpiar contenedor
  container.innerHTML = '';
  
  // Crear tarjeta de horarios
  const cardHorarios = document.createElement('div');
  cardHorarios.className = 'estadistica-card';
  
  if (datosHorarios.length === 0) {
    cardHorarios.innerHTML = `
      <h4>HORARIOS MÁS CONCURRIDOS</h4>
      <div class="estadisticas-vacio">
        <div class="icono-vacio">🕒</div>
        <p>No hay datos de horarios</p>
      </div>
    `;
  } else {
    const maxCantidad = Math.max(...datosHorarios.map(d => d.cantidad));
    
    // Generar marcas del eje Y
    const marcasY = [];
    for (let i = maxCantidad; i >= 0; i -= Math.ceil(maxCantidad / 4)) {
      if (i >= 0) marcasY.push(i);
    }
    
    cardHorarios.innerHTML = `
      <h4>HORARIOS MÁS CONCURRIDOS</h4>
      <div class="grafica-container">
        <div class="eje-y">
          ${marcasY.map(marca => `<div class="marca-y">${marca}</div>`).join('')}
        </div>
        <div class="grafica-barras">
          ${datosHorarios.map(dato => {
            const altura = (dato.cantidad / maxCantidad) * 100;
            const esDestacada = dato.cantidad === maxCantidad;
            return `
              <div class="barra-container">
                <div class="barra ${esDestacada ? 'destacada' : ''}" 
                     style="height: ${altura}%" 
                     data-value="${dato.cantidad}">
                </div>
                <div class="etiqueta">${dato.horario}</div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }
  
  container.appendChild(cardHorarios);
}

/**
 * 📊 Generar gráfica de servicios más solicitados
 */
function generarGraficaServicios(datosServicios) {
  const container = document.querySelector('.estadisticas-container');
  
  // Crear tarjeta de servicios
  const cardServicios = document.createElement('div');
  cardServicios.className = 'estadistica-card';
  
  if (datosServicios.length === 0) {
    cardServicios.innerHTML = `
      <h4>SERVICIOS MÁS SOLICITADOS</h4>
      <div class="estadisticas-vacio">
        <div class="icono-vacio">🔬</div>
        <p>No hay datos de servicios</p>
      </div>
    `;
  } else {
    const maxCantidad = Math.max(...datosServicios.map(d => d.cantidad));
    
    // Generar marcas del eje Y
    const marcasY = [];
    for (let i = maxCantidad; i >= 0; i -= Math.ceil(maxCantidad / 4)) {
      if (i >= 0) marcasY.push(i);
    }
    
    cardServicios.innerHTML = `
      <h4>SERVICIOS MÁS SOLICITADOS</h4>
      <div class="grafica-container">
        <div class="eje-y">
          ${marcasY.map(marca => `<div class="marca-y">${marca}</div>`).join('')}
        </div>
        <div class="grafica-barras">
          ${datosServicios.map(dato => {
            const altura = (dato.cantidad / maxCantidad) * 100;
            const esDestacada = dato.cantidad === maxCantidad;
            // Acortar nombres largos de servicios
            const nombreCorto = dato.servicio.length > 12 
              ? dato.servicio.substring(0, 10) + '...' 
              : dato.servicio;
            return `
              <div class="barra-container">
                <div class="barra ${esDestacada ? 'destacada' : ''}" 
                     style="height: ${altura}%" 
                     data-value="${dato.cantidad}"
                     title="${dato.servicio}: ${dato.cantidad} citas">
                </div>
                <div class="etiqueta" title="${dato.servicio}">${nombreCorto}</div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }
  
  container.appendChild(cardServicios);
}

/**
 * 📊 Mostrar gráficas vacías cuando no hay datos
 */
function mostrarGraficasVacias() {
  let container = document.querySelector('.estadisticas-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'estadisticas-container';
    
    const serviciosContainer = document.getElementById('servicios-container');
    if (serviciosContainer && serviciosContainer.parentNode) {
      serviciosContainer.parentNode.appendChild(container);
    }
  }
  
  container.innerHTML = `
    <div class="estadistica-card">
      <h4>HORARIOS MÁS CONCURRIDOS</h4>
      <div class="estadisticas-vacio">
        <div class="icono-vacio">🕒</div>
        <p>No hay citas aceptadas aún</p>
      </div>
    </div>
    <div class="estadistica-card">
      <h4>SERVICIOS MÁS SOLICITADOS</h4>
      <div class="estadisticas-vacio">
        <div class="icono-vacio">🔬</div>
        <p>No hay citas aceptadas aún</p>
      </div>
    </div>
  `;
  
  console.log("📊 Mostrando gráficas vacías - No hay citas aceptadas");
}

// =================== FUNCIONES EXISTENTES (sin cambios) ===================

/**
 * Generar horarios disponibles automáticamente
 */
function generarHorariosDisponibles(horarioTexto) {
  const horarioSelect = document.getElementById("horario-select");
  
  // Limpiar opciones existentes (excepto la primera)
  while (horarioSelect.children.length > 1) {
    horarioSelect.removeChild(horarioSelect.lastChild);
  }
  
  // Si no hay horario definido, mostrar mensaje
  if (!horarioTexto || horarioTexto.trim() === "") {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "Horario no disponible";
    option.disabled = true;
    horarioSelect.appendChild(option);
    console.log("⚠️ No hay horario definido");
    return;
  }
  
  console.log("🔍 Procesando horario original:", horarioTexto);
  
  try {
    // Parsear el horario del veterinario
    const { horaInicio, horaFin } = parsearHorario(horarioTexto);
    
    console.log("⏰ Horas parseadas:", { horaInicio, horaFin });
    
    if (!horaInicio || !horaFin) {
      throw new Error("No se pudo interpretar el horario");
    }
    
    // Generar intervalos de 30 minutos
    const horarios = generarIntervalosHorario(horaInicio, horaFin);
    
    if (horarios.length === 0) {
      throw new Error("No se generaron horarios válidos");
    }
    
    // Agregar cada horario como opción
    horarios.forEach((horario, index) => {
      const option = document.createElement("option");
      option.value = horario;
      option.textContent = horario;
      horarioSelect.appendChild(option);
      
      if (index < 5 || index >= horarios.length - 5) {
        console.log(`📝 Opción agregada [${index + 1}]: ${horario}`);
      } else if (index === 5) {
        console.log(`📝 ... (${horarios.length - 10} horarios más) ...`);
      }
    });
    
    console.log(`✅ Generados ${horarios.length} horarios desde ${horaInicio} hasta ${horaFin}`);
    console.log(`🎯 Primer horario: ${horarios[0]}, Último horario: ${horarios[horarios.length - 1]}`);
    
  } catch (error) {
    console.error("❌ Error al generar horarios:", error.message);
    
    // Agregar horarios de respaldo
    const horariosRespaldo = [
      "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
      "12:00", "12:30", "13:00", "13:30", "14:00", "14:30",
      "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
      "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00"
    ];
    
    horariosRespaldo.forEach(horario => {
      const option = document.createElement("option");
      option.value = horario;
      option.textContent = horario;
      horarioSelect.appendChild(option);
    });
    
    console.log("⚠️ Usando horarios de respaldo:", horariosRespaldo);
  }
}

/**
 * Parsear diferentes formatos de horario
 */
function parsearHorario(horarioTexto) {
  // Limpiar el texto y normalizar
  const texto = horarioTexto.toLowerCase().trim()
    .replace(/\s+/g, ' ') // Normalizar espacios
    .replace(/[–—]/g, '-') // Normalizar guiones
    .replace(/\./g, ':'); // Cambiar puntos por dos puntos
  
  console.log("🔍 Texto normalizado:", `"${texto}"`);
  
  // Patrón más específico para AM/PM
  const patronAMPM = /(\d{1,2})(?::(\d{2}))?\s*(am|pm)\s*[-]\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)/;
  const matchAMPM = texto.match(patronAMPM);
  
  if (matchAMPM) {
    const [, horaInicio, minutoInicio, periodoInicio, horaFin, minutoFin, periodoFin] = matchAMPM;
    
    console.log("📊 Match AM/PM detectado:", {
      horaInicio: horaInicio,
      minutoInicio: minutoInicio || '00',
      periodoInicio: periodoInicio,
      horaFin: horaFin,
      minutoFin: minutoFin || '00',
      periodoFin: periodoFin
    });
    
    // Convertir a formato 24 horas
    const inicio24 = convertirAMPMA24Horas(parseInt(horaInicio), parseInt(minutoInicio || 0), periodoInicio);
    const fin24 = convertirAMPMA24Horas(parseInt(horaFin), parseInt(minutoFin || 0), periodoFin);
    
    console.log("🔄 Conversión 24h:", { 
      inicio: `${inicio24.hora}:${inicio24.minuto}`,
      fin: `${fin24.hora}:${fin24.minuto}`
    });
    
    const horaInicioFormateada = `${inicio24.hora.toString().padStart(2, '0')}:${inicio24.minuto.toString().padStart(2, '0')}`;
    const horaFinFormateada = `${fin24.hora.toString().padStart(2, '0')}:${fin24.minuto.toString().padStart(2, '0')}`;
    
    console.log("✅ Resultado final:", { 
      horaInicio: horaInicioFormateada, 
      horaFin: horaFinFormateada 
    });
    
    return {
      horaInicio: horaInicioFormateada,
      horaFin: horaFinFormateada
    };
  }
  
  // Patrón para formato 24 horas
  const patron24h = /(\d{1,2})(?::(\d{2}))?\s*[-]\s*(\d{1,2})(?::(\d{2}))?/;
  const match24h = texto.match(patron24h);
  
  if (match24h) {
    const [, horaInicio, minutoInicio, horaFin, minutoFin] = match24h;
    
    console.log("📊 Match 24h detectado:", {
      horaInicio, minutoInicio: minutoInicio || '00',
      horaFin, minutoFin: minutoFin || '00'
    });
    
    return {
      horaInicio: `${horaInicio.padStart(2, '0')}:${(minutoInicio || '00').padStart(2, '0')}`,
      horaFin: `${horaFin.padStart(2, '0')}:${(minutoFin || '00').padStart(2, '0')}`
    };
  }
  
  // Si no coincide con ningún patrón, retornar null
  console.log("❌ No se encontró patrón válido en:", `"${texto}"`);
  return { horaInicio: null, horaFin: null };
}

/**
 * Convertir hora AM/PM a formato 24 horas
 */
function convertirAMPMA24Horas(hora, minuto, periodo) {
  let hora24 = hora;
  
  console.log(`🔄 Convirtiendo: ${hora}:${minuto.toString().padStart(2, '0')} ${periodo.toUpperCase()}`);
  
  if (periodo === 'pm' && hora !== 12) {
    // PM y no es 12: sumar 12 horas
    hora24 = hora + 12;
    console.log(`   PM (no 12): ${hora} + 12 = ${hora24}`);
  } else if (periodo === 'am' && hora === 12) {
    // 12 AM es medianoche: convertir a 0
    hora24 = 0;
    console.log(`   12 AM: ${hora} → ${hora24} (medianoche)`);
  } else if (periodo === 'pm' && hora === 12) {
    // 12 PM permanece como 12 (mediodía)
    hora24 = 12;
    console.log(`   12 PM: ${hora} → ${hora24} (mediodía)`);
  } else {
    console.log(`   AM (no 12): ${hora} → ${hora24} (sin cambio)`);
  }
  
  console.log(`✅ Resultado: ${hora24}:${minuto.toString().padStart(2, '0')}`);
  
  return { hora: hora24, minuto: minuto };
}

/**
 * Generar intervalos de horario cada 30 minutos
 */
function generarIntervalosHorario(horaInicio, horaFin) {
  const intervalos = [];
  
  // Parsear hora de inicio y fin
  const [inicioHora, inicioMinuto] = horaInicio.split(':').map(n => parseInt(n));
  const [finHora, finMinuto] = horaFin.split(':').map(n => parseInt(n));
  
  console.log(`🕐 Generando intervalos desde ${inicioHora}:${inicioMinuto} hasta ${finHora}:${finMinuto}`);
  
  // Usar minutos totales para cálculos más precisos
  const inicioMinutosTotales = inicioHora * 60 + inicioMinuto;
  const finMinutosTotales = finHora * 60 + finMinuto;
  
  console.log(`📊 Minutos totales: inicio=${inicioMinutosTotales}, fin=${finMinutosTotales}`);
  
  // Generar intervalos de 30 minutos
  let minutosActuales = inicioMinutosTotales;
  const intervalo = 30; // minutos
  
  while (minutosActuales <= finMinutosTotales) {
    // Convertir minutos totales de vuelta a horas:minutos
    const hora = Math.floor(minutosActuales / 60);
    const minuto = minutosActuales % 60;
    
    // Formatear como HH:MM
    const horaFormateada = `${hora.toString().padStart(2, '0')}:${minuto.toString().padStart(2, '0')}`;
    intervalos.push(horaFormateada);
    
    console.log(`⏰ Agregando horario: ${horaFormateada} (minutos: ${minutosActuales})`);
    
    // Avanzar 30 minutos
    minutosActuales += intervalo;
  }
  
  console.log(`📅 Total de intervalos generados: ${intervalos.length}`);
  console.log(`🎯 Intervalos completos:`, intervalos);
  
  return intervalos;
}

/**
 * Llena los campos con la información del especialista
 */
function llenarDatosEspecialista(datos) {
  // Campos del tab CONSULTORIO
  document.getElementById("nombre-clinica").value = datos.clinica || datos.nombreVeterinaria || "";
  document.getElementById("nombre-vet").value = datos.nombre || "";
  document.getElementById("titulo-vet").value = "Médico Veterinario Zootecnista";
  document.getElementById("cedula-vet").value = datos.cedula || "";
  document.getElementById("descripcion-vet").value = datos.descripcion || "";
  document.getElementById("ubicacion").value = datos.calle || datos.ubicacion || "";
  document.getElementById("telefono").value = datos.telefono || "";
  document.getElementById("horario").value = datos.horario || "";
  
  // Cargar imagen personalizada si existe
  const fotoVet = document.querySelector('.foto-vet');
  if (fotoVet && datos.fotoPerfil) {
    fotoVet.src = datos.fotoPerfil;
  }
}

/**
 * Carga los servicios en la lista de servicios y precios
 */
function cargarServiciosLista(servicios) {
  const contenedor = document.getElementById("servicios-container");
  contenedor.innerHTML = ""; // Limpiar contenido previo
  
  if (servicios.length === 0) {
    contenedor.innerHTML = "<p>No hay servicios disponibles.</p>";
    return;
  }
  
  servicios.forEach(servicio => {
    const servicioDiv = document.createElement("div");
    servicioDiv.className = "serv-fila";
    servicioDiv.innerHTML = `
      <strong>${servicio.nombre}</strong>
      <span>$${servicio.precio}</span>
    `;
    contenedor.appendChild(servicioDiv);
  });
}

/**
 * Carga los servicios en el dropdown para agendar cita
 */
function cargarServiciosDropdown(servicios) {
  const select = document.getElementById("servicio-select");
  
  // Limpiar opciones previas (excepto la primera)
  while (select.children.length > 1) {
    select.removeChild(select.lastChild);
  }
  
  // Agregar servicios como opciones
  servicios.forEach(servicio => {
    const option = document.createElement("option");
    option.value = JSON.stringify({
      nombre: servicio.nombre,
      precio: servicio.precio
    });
    option.textContent = `${servicio.nombre} - $${servicio.precio}`;
    select.appendChild(option);
  });
}

/**
 * Configura los eventos del formulario para agendar cita
 */
function configurarFormularioCita(datosEspecialista, especialistaCorreo) {
  const btnEnviar = document.getElementById("btn-enviar");
  const btnEliminar = document.getElementById("btn-eliminar");
  
  // Configurar fecha mínima (hoy)
  const fechaInput = document.getElementById("fecha-cita");
  if (fechaInput) {
    const hoy = new Date().toISOString().split('T')[0];
    fechaInput.setAttribute('min', hoy);
  }
  
  // Evento para enviar la cita
  btnEnviar.addEventListener("click", () => {
    enviarCitaReal(datosEspecialista, especialistaCorreo);
  });
  
  // Evento para limpiar/eliminar el formulario
  btnEliminar.addEventListener("click", () => {
    if (confirm("¿Estás seguro de que quieres limpiar el formulario?")) {
      limpiarFormularioCita();
    }
  });
}

/**
 * Enviar cita real al sistema
 */
function enviarCitaReal(datosEspecialista, especialistaCorreo) {
  // Verificar que el tutor esté logueado
  const infoTutor = JSON.parse(localStorage.getItem("ultimoUsuario"));
  if (!infoTutor || infoTutor.tipo !== "tutor") {
    alert("Debes estar logueado como tutor para agendar una cita.");
    location.href = "../index.html";
    return;
  }
  
  // Obtener datos del formulario
  const servicioRaw = document.getElementById("servicio-select").value;
  const horario = document.getElementById("horario-select").value;
  const fecha = document.getElementById("fecha-cita").value;
  const motivo = document.getElementById("motivo-consulta").value;
  
  // Validar campos requeridos
  if (!servicioRaw) {
    alert("Por favor selecciona un servicio.");
    return;
  }
  
  if (!horario) {
    alert("Por favor selecciona un horario.");
    return;
  }
  
  if (!fecha) {
    alert("Por favor selecciona una fecha.");
    return;
  }
  
  if (!motivo.trim()) {
    alert("Por favor describe el motivo de la consulta.");
    return;
  }
  
  // Obtener datos del tutor
  const datosTutor = JSON.parse(localStorage.getItem(`register-tutor-${infoTutor.correo}`));
  if (!datosTutor) {
    alert("Error: No se encontraron tus datos de tutor.");
    return;
  }
  
  // Parsear información del servicio
  let servicio;
  try {
    servicio = JSON.parse(servicioRaw);
  } catch (error) {
    alert("Error al procesar el servicio seleccionado.");
    return;
  }
  
  // Crear objeto de cita
  const nuevaCita = {
    id: Date.now().toString(), // ID único
    
    // Información del tutor
    tutorCorreo: infoTutor.correo,
    tutorNombre: `${datosTutor.nombre} ${datosTutor.apellidos}`.trim(),
    
    // Información del especialista
    especialistaCorreo: especialistaCorreo,
    especialistaNombre: datosEspecialista.nombre,
    clinica: datosEspecialista.clinica || datosEspecialista.nombreVeterinaria,
    
    // Información de la cita
    servicio: servicio.nombre,
    precio: servicio.precio,
    horario: horario,
    fecha: fecha,
    motivo: motivo.trim(),
    
    // Estados y fechas
    estado: 'pendiente',
    fechaCreacion: new Date().toISOString(),
    fechaRespuesta: null
  };
  
  try {
    // Guardar cita para el especialista
    const citasEspecialista = JSON.parse(localStorage.getItem(`citas-${especialistaCorreo}`)) || [];
    citasEspecialista.push(nuevaCita);
    localStorage.setItem(`citas-${especialistaCorreo}`, JSON.stringify(citasEspecialista));
    
    // Guardar cita para el tutor
    const citasTutor = JSON.parse(localStorage.getItem(`citas-tutor-${infoTutor.correo}`)) || [];
    citasTutor.push(nuevaCita);
    localStorage.setItem(`citas-tutor-${infoTutor.correo}`, JSON.stringify(citasTutor));
    
    // Mostrar mensaje de éxito
    alert(`¡Solicitud de cita enviada correctamente! 📅\n\n` +
          `Veterinario: Dr. ${datosEspecialista.nombre}\n` +
          `Servicio: ${servicio.nombre}\n` +
          `Fecha: ${formatearFechaLegible(fecha)}\n` +
          `Hora: ${horario}\n\n` +
          `Te contactaremos pronto para confirmar tu cita.`);
    
    // Limpiar formulario
    limpiarFormularioCita();
    
    console.log("✅ Cita enviada exitosamente:", nuevaCita);
    
  } catch (error) {
    console.error("❌ Error al enviar la cita:", error);
    alert("Error al enviar la cita. Por favor intenta nuevamente.");
  }
}

/**
 * Limpia todos los campos del formulario de cita
 */
function limpiarFormularioCita() {
  document.getElementById("servicio-select").value = "";
  document.getElementById("horario-select").value = "";
  document.getElementById("fecha-cita").value = "";
  document.getElementById("motivo-consulta").value = "";
}

/**
 * Formatear fecha para mostrar de forma legible
 */
function formatearFechaLegible(fecha) {
  const date = new Date(fecha);
  return date.toLocaleDateString('es-ES', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

/**
 * Configurar validaciones adicionales
 */
document.addEventListener("DOMContentLoaded", () => {
  // Validar que la fecha no sea pasada
  const fechaInput = document.getElementById("fecha-cita");
  if (fechaInput) {
    fechaInput.addEventListener('change', () => {
      const fechaSeleccionada = new Date(fechaInput.value);
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      
      if (fechaSeleccionada < hoy) {
        alert("No puedes seleccionar una fecha pasada.");
        fechaInput.value = "";
      }
    });
  }
  
  // Validar horario según día de la semana (opcional)
  const horarioSelect = document.getElementById("horario-select");
  const fechaInputVal = document.getElementById("fecha-cita");
  
  if (horarioSelect && fechaInputVal) {
    fechaInputVal.addEventListener('change', () => {
      const fecha = new Date(fechaInputVal.value);
      const diaSemana = fecha.getDay(); // 0 = domingo, 6 = sábado
      
      // Ejemplo: restringir horarios en fin de semana
      if (diaSemana === 0 || diaSemana === 6) {
        // Fin de semana - horarios limitados
        console.log("Fin de semana detectado - horarios limitados disponibles");
      }
    });
  }
});