// Variables globales
let mascotas = [];
let indiceMascotaActual = 0;
let modoEdicionUsuario = false;
let modoEdicionMascota = false;
let datosOriginalesUsuario = {};
let datosOriginalesMascota = {};
let imagenMascotaSeleccionada = null;

// Variables para citas del tutor
let citasTutor = [];
let filtroTutorActual = 'todas';

// Referencias DOM
const tabDatos = document.getElementById("tab-datos");
const tabMascota = document.getElementById("tab-mascota");
const tabCitas = document.getElementById("tab-citas");
const seccionDatos = document.getElementById("seccion-datos");
const seccionMascota = document.getElementById("seccion-mascota");
const seccionCitas = document.getElementById("seccion-citas");
const form = document.getElementById("form-datos");

// Referencias DOM - Usuario
const btnEditarUsuario = document.getElementById("editar-perfil");
const btnGuardarUsuario = document.getElementById("guardar-cambios");

// Referencias DOM - Mascotas
const mascotaCont = document.getElementById("mascota-contenedor");
const mascotaVacia = document.getElementById("mascota-vacia");
const btnAnterior = document.getElementById("btn-anterior");
const btnSiguiente = document.getElementById("btn-siguiente");
const indicadorPosicion = document.getElementById("indicador-posicion");

// Referencias DOM - Botones mascota
const btnEditarMascota = document.getElementById("btn-editar-mascota");
const btnGuardarMascota = document.getElementById("btn-guardar-mascota");
const btnCancelarMascota = document.getElementById("btn-cancelar-mascota");
const btnEliminarMascota = document.getElementById("btn-eliminar-mascota");
const btnAgregarMascota = document.getElementById("btn-agregar-otra-mascota");
const btnNuevaMascota = document.getElementById("btn-nueva-mascota");

// Inicialización principal
document.addEventListener("DOMContentLoaded", () => {
  const infoUsuario = verificarAutenticacion();
  if (!infoUsuario) return;
  
  cargarDatosUsuario();
  configurarPestanas();
  configurarEdicionUsuario();
  configurarGuardadoUsuario();
  migrarDatosMascota();
  cargarMascotas();
  configurarNavegacionMascotas();
  configurarEdicionMascota();
  configurarModalImagen();
  configurarBotonesMascota();
  
  // Verificar si viene de registro nuevo
  verificarRegistroNuevo();
  
  // Inicializar sistema de citas
  inicializarSistemaCitasTutor();
});

/**
 * Verificar autenticación del usuario
 */
function verificarAutenticacion() {
  const info = JSON.parse(localStorage.getItem("ultimoUsuario"));
  if (!info || info.tipo !== "tutor") {
    alert("No estás logueado correctamente.");
    location.href = "../index.html";
    return null;
  }
  return info;
}

/**
 * Cargar datos del usuario en el formulario
 */
function cargarDatosUsuario() {
  const infoUsuario = verificarAutenticacion();
  if (!infoUsuario) return;

  const datos = JSON.parse(localStorage.getItem(`register-tutor-${infoUsuario.correo}`));
  if (!datos) return alert("No se encontraron tus datos.");

  document.getElementById("nombre").value = datos.nombre || "";
  document.getElementById("apellidos").value = datos.apellidos || "";
  document.getElementById("telefono").value = datos.telefono || "";
  document.getElementById("correo").value = datos.correo || "";
  document.getElementById("direccion").value = datos.calle || "";
}

/**
 * Configurar navegación entre pestañas - ACTUALIZADA PARA INCLUIR CITAS
 */
function configurarPestanas() {
  tabDatos.onclick = () => {
    activarTab(tabDatos, seccionDatos);
  };
  
  tabMascota.onclick = () => {
    activarTab(tabMascota, seccionMascota);
  };
  
  tabCitas.onclick = () => {
    activarTab(tabCitas, seccionCitas);
    cargarCitasTutor(); // Cargar citas al abrir la pestaña
  };
  
  function activarTab(tabActivo, seccionActiva) {
    // Remover active de todos
    [tabDatos, tabMascota, tabCitas].forEach(tab => tab.classList.remove("active"));
    [seccionDatos, seccionMascota, seccionCitas].forEach(seccion => seccion.classList.add("oculto"));
    
    // Activar seleccionado
    tabActivo.classList.add("active");
    seccionActiva.classList.remove("oculto");
  }
}

/**
 * Configurar edición de perfil de usuario
 */
function configurarEdicionUsuario() {
  btnEditarUsuario.onclick = () => {
    const inputs = form.querySelectorAll("input, select");

    if (!modoEdicionUsuario) {
      datosOriginalesUsuario = {};
      inputs.forEach(input => {
        datosOriginalesUsuario[input.id] = input.value;
        if (input.id !== "correo") {
          input.disabled = false;
          input.removeAttribute("readonly");
        }
      });
      btnGuardarUsuario.classList.remove("oculto");
      btnEditarUsuario.textContent = "CANCELAR";
      modoEdicionUsuario = true;
    } else {
      inputs.forEach(input => {
        input.value = datosOriginalesUsuario[input.id];
        input.disabled = true;
        if (input.tagName === "INPUT") input.setAttribute("readonly", "true");
      });
      btnGuardarUsuario.classList.add("oculto");
      btnEditarUsuario.textContent = "EDITAR PERFIL";
      modoEdicionUsuario = false;
    }
  };
}

/**
 * Configurar guardado de cambios del usuario
 */
function configurarGuardadoUsuario() {
  form.onsubmit = e => {
    e.preventDefault();
    const info = verificarAutenticacion();
    if (!info) return;

    const datosActualizados = {
      correo: info.correo,
      nombre: document.getElementById("nombre").value.trim(),
      apellidos: document.getElementById("apellidos").value.trim(),
      telefono: document.getElementById("telefono").value.trim(),
      calle: document.getElementById("direccion").value
    };

    const existentes = JSON.parse(localStorage.getItem(`register-tutor-${info.correo}`)) || {};
    const nuevos = { ...existentes, ...datosActualizados };

    localStorage.setItem(`register-tutor-${info.correo}`, JSON.stringify(nuevos));
    alert("Cambios guardados correctamente.");

    const inputs = form.querySelectorAll("input, select");
    inputs.forEach(input => {
      input.disabled = true;
      if (input.tagName === "INPUT") input.setAttribute("readonly", "true");
    });

    btnGuardarUsuario.classList.add("oculto");
    btnEditarUsuario.textContent = "EDITAR PERFIL";
    modoEdicionUsuario = false;
  };
}

/**
 * Migrar datos de mascota única a sistema de múltiples mascotas
 */
function migrarDatosMascota() {
  const info = verificarAutenticacion();
  if (!info) return;

  const mascotasExistentes = localStorage.getItem(`mascotas-${info.correo}`);
  if (mascotasExistentes) return;

  const mascotaAntigua = localStorage.getItem(`mascota-${info.correo}`);
  if (mascotaAntigua) {
    try {
      const mascota = JSON.parse(mascotaAntigua);
      mascota.id = Date.now();
      const arrayMascotas = [mascota];
      
      localStorage.setItem(`mascotas-${info.correo}`, JSON.stringify(arrayMascotas));
      localStorage.removeItem(`mascota-${info.correo}`);
      
      console.log("Datos migrados exitosamente al nuevo formato");
    } catch (error) {
      console.error("Error al migrar datos de mascota:", error);
    }
  }
}

/**
 * Cargar todas las mascotas del usuario
 */
function cargarMascotas() {
  const info = verificarAutenticacion();
  if (!info) return;

  const mascotasGuardadas = localStorage.getItem(`mascotas-${info.correo}`);
  mascotas = mascotasGuardadas ? JSON.parse(mascotasGuardadas) : [];

  if (mascotas.length === 0) {
    mostrarEstadoVacio();
  } else {
    indiceMascotaActual = 0;
    mostrarMascota();
  }
}

/**
 * Mostrar estado vacío (sin mascotas)
 */
function mostrarEstadoVacio() {
  mascotaCont.classList.add("oculto");
  mascotaVacia.classList.remove("oculto");
}

/**
 * Mostrar mascota actual
 */
function mostrarMascota() {
  if (mascotas.length === 0) {
    mostrarEstadoVacio();
    return;
  }

  mascotaVacia.classList.add("oculto");
  mascotaCont.classList.remove("oculto");

  const mascota = mascotas[indiceMascotaActual];
  
  indicadorPosicion.textContent = `PERFIL - MASCOTA ${indiceMascotaActual + 1}`;
  
  document.getElementById("m-nombre").value = mascota.nombre || "";
  document.getElementById("m-fecha").value = mascota.fecha || "";
  document.getElementById("m-edad").value = mascota.edad || "";
  document.getElementById("m-sexo").value = mascota.sexo || "Macho";
  document.getElementById("m-raza").value = mascota.raza || "";
  document.getElementById("m-especie").value = mascota.especie || "Animal doméstico";
  
  const imgMascota = document.getElementById("m-imagen");
  if (mascota.imagen) {
    imgMascota.src = mascota.imagen;
  } else {
    imgMascota.src = "../imagenes/perfil-icono.png";
  }
  
  btnAnterior.disabled = indiceMascotaActual === 0;
  btnSiguiente.disabled = indiceMascotaActual === mascotas.length - 1;
}

/**
 * Configurar navegación entre mascotas
 */
function configurarNavegacionMascotas() {
  btnAnterior.onclick = () => {
    if (indiceMascotaActual > 0) {
      indiceMascotaActual--;
      mostrarMascota();
    }
  };

  btnSiguiente.onclick = () => {
    if (indiceMascotaActual < mascotas.length - 1) {
      indiceMascotaActual++;
      mostrarMascota();
    }
  };
}

/**
 * Configurar edición de mascota
 */
function configurarEdicionMascota() {
  btnEditarMascota.onclick = () => {
    const campos = document.querySelectorAll("#mascota-contenedor input, #mascota-contenedor select");

    if (!modoEdicionMascota) {
      datosOriginalesMascota = {};
      campos.forEach(campo => {
        datosOriginalesMascota[campo.id] = campo.value;
        campo.disabled = false;
      });
      
      btnGuardarMascota.classList.remove("oculto");
      btnCancelarMascota.classList.remove("oculto");
      btnEditarMascota.classList.add("oculto");
      btnEliminarMascota.disabled = true;
      btnAnterior.disabled = true;
      btnSiguiente.disabled = true;
      
      modoEdicionMascota = true;
    }
  };

  btnCancelarMascota.onclick = () => {
    if (modoEdicionMascota) {
      const campos = document.querySelectorAll("#mascota-contenedor input, #mascota-contenedor select");
      campos.forEach(campo => {
        campo.value = datosOriginalesMascota[campo.id];
        campo.disabled = true;
      });
      
      btnGuardarMascota.classList.add("oculto");
      btnCancelarMascota.classList.add("oculto");
      btnEditarMascota.classList.remove("oculto");
      btnEliminarMascota.disabled = false;
      
      btnAnterior.disabled = indiceMascotaActual === 0;
      btnSiguiente.disabled = indiceMascotaActual === mascotas.length - 1;
      
      modoEdicionMascota = false;
    }
  };

  btnGuardarMascota.onclick = () => {
    if (modoEdicionMascota) {
      guardarCambiosMascota();
    }
  };
}

/**
 * Guardar cambios de la mascota
 */
function guardarCambiosMascota() {
  const info = verificarAutenticacion();
  if (!info) return;

  const mascotaActualizada = {
    ...mascotas[indiceMascotaActual],
    nombre: document.getElementById("m-nombre").value.trim(),
    fecha: document.getElementById("m-fecha").value,
    edad: document.getElementById("m-edad").value,
    sexo: document.getElementById("m-sexo").value,
    raza: document.getElementById("m-raza").value.trim(),
    especie: document.getElementById("m-especie").value
  };

  if (!mascotaActualizada.nombre) {
    alert("El nombre de la mascota es requerido.");
    return;
  }

  mascotas[indiceMascotaActual] = mascotaActualizada;
  localStorage.setItem(`mascotas-${info.correo}`, JSON.stringify(mascotas));
  
  const campos = document.querySelectorAll("#mascota-contenedor input, #mascota-contenedor select");
  campos.forEach(campo => {
    campo.disabled = true;
  });
  
  btnGuardarMascota.classList.add("oculto");
  btnCancelarMascota.classList.add("oculto");
  btnEditarMascota.classList.remove("oculto");
  btnEliminarMascota.disabled = false;
  
  btnAnterior.disabled = indiceMascotaActual === 0;
  btnSiguiente.disabled = indiceMascotaActual === mascotas.length - 1;
  
  modoEdicionMascota = false;
  
  alert("Cambios guardados correctamente ✅");
}

/**
 * Configurar botones de mascota
 */
function configurarBotonesMascota() {
  if (btnNuevaMascota) {
    btnNuevaMascota.onclick = () => {
      location.href = '../registro-mascota/registro.html';
    };
  }

  if (btnAgregarMascota) {
    btnAgregarMascota.onclick = () => {
      location.href = '../registro-mascota/registro.html';
    };
  }

  if (btnEliminarMascota) {
    btnEliminarMascota.onclick = () => {
      if (confirm("¿Estás seguro de eliminar esta mascota? Esta acción no se puede deshacer.")) {
        eliminarMascota();
      }
    };
  }
}

/**
 * Eliminar mascota actual
 */
function eliminarMascota() {
  const info = verificarAutenticacion();
  if (!info) return;

  mascotas.splice(indiceMascotaActual, 1);
  localStorage.setItem(`mascotas-${info.correo}`, JSON.stringify(mascotas));

  if (mascotas.length === 0) {
    mostrarEstadoVacio();
  } else {
    if (indiceMascotaActual >= mascotas.length) {
      indiceMascotaActual = mascotas.length - 1;
    }
    mostrarMascota();
  }

  alert("Mascota eliminada correctamente.");
}

/**
 * Configurar modal para cambiar imagen de mascota
 */
function configurarModalImagen() {
  const imagenWrapper = document.getElementById('imagen-wrapper');
  const modal = document.getElementById('modal-imagen-mascota');
  const modalClose = document.getElementById('modal-close-mascota');
  const uploadArea = document.getElementById('upload-area-mascota');
  const fileInput = document.getElementById('file-input-mascota');
  const imagePreview = document.getElementById('image-preview-mascota');
  const previewImg = document.getElementById('preview-img-mascota');
  const btnChange = document.getElementById('btn-change-mascota');
  const btnCancelar = document.getElementById('btn-cancelar-modal-mascota');
  const btnGuardarImagen = document.getElementById('btn-guardar-imagen-mascota');

  if (imagenWrapper) {
    imagenWrapper.addEventListener('click', () => {
      modal.classList.add('active');
      resetearModal();
    });
  }

  const cerrarModal = () => {
    modal.classList.remove('active');
    resetearModal();
  };

  if (modalClose) modalClose.addEventListener('click', cerrarModal);
  if (btnCancelar) btnCancelar.addEventListener('click', cerrarModal);

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) cerrarModal();
    });
  }

  if (uploadArea) {
    uploadArea.addEventListener('click', () => fileInput.click());
    
    uploadArea.addEventListener('dragover', (e) => {
      e.preventDefault();
      uploadArea.classList.add('dragover');
    });

    uploadArea.addEventListener('dragleave', () => {
      uploadArea.classList.remove('dragover');
    });

    uploadArea.addEventListener('drop', (e) => {
      e.preventDefault();
      uploadArea.classList.remove('dragover');
      const files = e.dataTransfer.files;
      if (files.length > 0) {
        procesarArchivo(files[0]);
      }
    });
  }

  if (fileInput) {
    fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        procesarArchivo(e.target.files[0]);
      }
    });
  }

  if (btnChange) {
    btnChange.addEventListener('click', () => {
      fileInput.click();
    });
  }

  if (btnGuardarImagen) {
    btnGuardarImagen.addEventListener('click', () => {
      if (imagenMascotaSeleccionada) {
        guardarImagenMascota(imagenMascotaSeleccionada);
        cerrarModal();
      }
    });
  }

  function procesarArchivo(file) {
    if (!file.type.startsWith('image/')) {
      alert('Por favor selecciona un archivo de imagen válido.');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('La imagen es demasiado grande. Máximo 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      imagenMascotaSeleccionada = e.target.result;
      mostrarPreview(imagenMascotaSeleccionada);
    };
    reader.readAsDataURL(file);
  }

  function mostrarPreview(imagenBase64) {
    if (previewImg) previewImg.src = imagenBase64;
    if (uploadArea) uploadArea.style.display = 'none';
    if (imagePreview) imagePreview.style.display = 'block';
    if (btnGuardarImagen) btnGuardarImagen.disabled = false;
  }

  function resetearModal() {
    if (uploadArea) uploadArea.style.display = 'block';
    if (imagePreview) imagePreview.style.display = 'none';
    if (fileInput) fileInput.value = '';
    imagenMascotaSeleccionada = null;
    if (btnGuardarImagen) btnGuardarImagen.disabled = true;
  }
}

/**
 * Guardar imagen de la mascota
 */
function guardarImagenMascota(imagenBase64) {
  const info = verificarAutenticacion();
  if (!info) return;

  mascotas[indiceMascotaActual].imagen = imagenBase64;
  localStorage.setItem(`mascotas-${info.correo}`, JSON.stringify(mascotas));
  document.getElementById('m-imagen').src = imagenBase64;
  
  alert('Imagen de mascota guardada correctamente ✅');
}

/**
 * Verificar si viene de un registro nuevo y navegar apropiadamente
 */
function verificarRegistroNuevo() {
  const urlParams = new URLSearchParams(window.location.search);
  const tab = urlParams.get('tab');
  const nuevo = urlParams.get('nuevo');
  
  if (tab === 'mascota') {
    tabMascota.classList.add("active");
    tabDatos.classList.remove("active");
    seccionMascota.classList.remove("oculto");
    seccionDatos.classList.add("oculto");
    
    if (nuevo === 'true' && mascotas.length > 0) {
      indiceMascotaActual = mascotas.length - 1;
      mostrarMascota();
      
      setTimeout(() => {
        alert(`¡Bienvenida ${mascotas[indiceMascotaActual].nombre}! 🐾\nMascota registrada exitosamente.`);
      }, 500);
    }
    
    window.history.replaceState({}, document.title, window.location.pathname);
  }
}

// =============== SISTEMA DE CITAS DEL TUTOR ===============

/**
 * Inicializar sistema de citas del tutor
 */
function inicializarSistemaCitasTutor() {
  configurarFiltrosCitasTutor();
  configurarLimpiarBandejaTutor(); 
}

/**
 * Configurar filtros de citas del tutor
 */
function configurarFiltrosCitasTutor() {
  const filtros = document.querySelectorAll('.filtro-tutor-btn');
  
  filtros.forEach(filtro => {
    filtro.addEventListener('click', () => {
      filtros.forEach(f => f.classList.remove('active'));
      filtro.classList.add('active');
      
      if (filtro.id === 'filtro-tutor-todas') filtroTutorActual = 'todas';
      else if (filtro.id === 'filtro-tutor-pendientes') filtroTutorActual = 'pendiente';
      else if (filtro.id === 'filtro-tutor-aceptadas') filtroTutorActual = 'aceptada';
      else if (filtro.id === 'filtro-tutor-rechazadas') filtroTutorActual = 'rechazada';
      
      renderizarCitasTutor();
    });
  });
}

/**
 * Cargar citas del tutor
 */
function cargarCitasTutor() {
  const info = verificarAutenticacion();
  if (!info) return;
  
  const citasGuardadas = localStorage.getItem(`citas-tutor-${info.correo}`);
  citasTutor = citasGuardadas ? JSON.parse(citasGuardadas) : [];
  
  actualizarEstadisticasTutor();
  renderizarCitasTutor();
}

/**
 * Actualizar estadísticas de citas del tutor
 */
function actualizarEstadisticasTutor() {
  const pendientes = citasTutor.filter(c => c.estado === 'pendiente').length;
  const aceptadas = citasTutor.filter(c => c.estado === 'aceptada').length;
  const rechazadas = citasTutor.filter(c => c.estado === 'rechazada').length;
  
  document.getElementById('stat-tutor-pendientes').textContent = `${pendientes} Pendientes`;
  document.getElementById('stat-tutor-aceptadas').textContent = `${aceptadas} Aceptadas`;
  document.getElementById('stat-tutor-rechazadas').textContent = `${rechazadas} Rechazadas`;
}

/**
 * Renderizar lista de citas del tutor
 */
function renderizarCitasTutor() {
  const container = document.getElementById('citas-tutor-container');
  const vacio = document.getElementById('citas-tutor-vacio');
  
  let citasFiltradas = citasTutor;
  if (filtroTutorActual !== 'todas') {
    citasFiltradas = citasTutor.filter(c => c.estado === filtroTutorActual);
  }
  
  citasFiltradas.sort((a, b) => new Date(b.fechaCreacion) - new Date(a.fechaCreacion));
  
  if (citasFiltradas.length === 0) {
    container.classList.add('oculto');
    vacio.classList.remove('oculto');
    return;
  }
  
  container.classList.remove('oculto');
  vacio.classList.add('oculto');
  
  container.innerHTML = '';
  
  citasFiltradas.forEach(cita => {
    const citaCard = crearTarjetaCitaTutor(cita);
    container.appendChild(citaCard);
  });
}

/**
 * Crear tarjeta de cita para tutor
 */
function crearTarjetaCitaTutor(cita) {
  const card = document.createElement('div');
  card.className = `cita-card ${cita.estado}`;
  
  card.innerHTML = `
    <div class="cita-header">
      <div class="cita-info-principal">
        <div class="cita-tutor">${cita.clinica}</div>
        <div class="cita-servicio">Dr. ${cita.especialistaNombre}</div>
      </div>
      <span class="cita-estado ${cita.estado}">${obtenerTextoEstado(cita.estado)}</span>
    </div>
    
    <div class="cita-detalles">
      <div class="cita-detalle">
        <span class="cita-detalle-icono">🩺</span>
        <span class="cita-detalle-texto">Servicio:</span>
        <span class="cita-detalle-valor">${cita.servicio}</span>
      </div>
      <div class="cita-detalle">
        <span class="cita-detalle-icono">💰</span>
        <span class="cita-detalle-texto">Precio:</span>
        <span class="cita-detalle-valor">$${cita.precio}</span>
      </div>
      <div class="cita-detalle">
        <span class="cita-detalle-icono">📅</span>
        <span class="cita-detalle-texto">Fecha:</span>
        <span class="cita-detalle-valor">${formatearFecha(cita.fecha)}</span>
      </div>
      <div class="cita-detalle">
        <span class="cita-detalle-icono">🕒</span>
        <span class="cita-detalle-texto">Hora:</span>
        <span class="cita-detalle-valor">${cita.horario}</span>
      </div>
    </div>
    
    <div class="cita-motivo">
      <span class="cita-motivo-label">Tu motivo de consulta:</span>
      <div class="cita-motivo-texto">${cita.motivo}</div>
    </div>
    
    <div class="cita-timestamp">
      Enviada: ${formatearTimestamp(cita.fechaCreacion)}
      ${cita.fechaRespuesta ? `• Respondida: ${formatearTimestamp(cita.fechaRespuesta)}` : ''}
    </div>
  `;
  
  return card;
}

/**
 * Funciones auxiliares (compartidas)
 */
function obtenerTextoEstado(estado) {
  const estados = {
    'pendiente': 'Pendiente',
    'aceptada': 'Aceptada',
    'rechazada': 'Rechazada'
  };
  return estados[estado] || estado;
}

function formatearFecha(fecha) {
  const date = new Date(fecha);
  return date.toLocaleDateString('es-ES', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

function formatearTimestamp(timestamp) {
  const date = new Date(timestamp);
  return date.toLocaleString('es-ES', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

/**
 * Configurar botón limpiar bandeja del tutor
 */
function configurarLimpiarBandejaTutor() {
  const btnLimpiar = document.getElementById('btn-limpiar-bandeja-tutor');
  
  if (btnLimpiar) {
    btnLimpiar.addEventListener('click', () => {
      limpiarBandejaTutor();
    });
  }
}

/**
 * Limpiar bandeja del tutor (eliminar citas aceptadas y rechazadas)
 */
function limpiarBandejaTutor() {
  const info = verificarAutenticacion();
  if (!info) return;
  
  const citasAEliminar = citasTutor.filter(c => c.estado === 'aceptada' || c.estado === 'rechazada');
  
  if (citasAEliminar.length === 0) {
    alert('No hay citas aceptadas o rechazadas para eliminar.');
    return;
  }
  
  const mensaje = `¿Estás seguro de eliminar ${citasAEliminar.length} cita(s) aceptada(s) y rechazada(s)?\n\nLas citas pendientes se mantendrán.`;
  
  if (confirm(mensaje)) {
    // Mantener solo las citas pendientes
    citasTutor = citasTutor.filter(c => c.estado === 'pendiente');
    
    // Guardar cambios
    localStorage.setItem(`citas-tutor-${info.correo}`, JSON.stringify(citasTutor));
    
    // Actualizar vista
    actualizarEstadisticasTutor();
    renderizarCitasTutor();
    
    alert(`Bandeja limpiada correctamente ✅\n${citasAEliminar.length} cita(s) eliminada(s)`);
  }
}