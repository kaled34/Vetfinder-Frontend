const form = document.getElementById('especialistaForm');
const mensaje = document.getElementById('mensaje');
const calle = document.getElementById('calle');

const callesPorColonia = {
  bosque: [
    "AV. DE LOS TREBOLES",
    "AV. DE LOS DÁTILES",
    "AV. DEL TULE",
    "AV. DEL FRESNO",
    "AV. DE LOS PERALES"
  ]
};

colonia.addEventListener('change', () => {
  const valor = colonia.value;
  calle.innerHTML = '<option value="">Nombre de la calle</option>';
  if (valor && callesPorColonia[valor]) {
    callesPorColonia[valor].forEach(c => {
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = c;
      calle.appendChild(opt);
    });
  }
});

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const campos = [
    'nombre', 'apellidos', 'email', 'telefono', 'password',
    'colonia', 'calle', 'consultorio', 'especialidad', 'cedula'
  ];

  const vacios = campos.filter(id => !document.getElementById(id).value.trim());

  if (vacios.length > 0) {
    mostrarMensaje("¡Atención! Verifica los campos resaltados y complétalos.", "error");
  } else {
    mostrarMensaje("¡Listo! Tus datos han sido guardados.", "success");
    form.reset();
  }
});

function mostrarMensaje(texto, tipo) {
  mensaje.textContent = texto;
  mensaje.className = `mensaje ${tipo}`;
  mensaje.classList.remove('oculto');
  setTimeout(() => mensaje.classList.add('oculto'), 4000);
}
