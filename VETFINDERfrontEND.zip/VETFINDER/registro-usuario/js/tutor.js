console.log("📦 Cargando perfil-tutor.js...");
const infoUsuario = JSON.parse(localStorage.getItem("ultimoUsuario"));
console.log("👤 Usuario detectado:", infoUsuario);

if (!infoUsuario || infoUsuario.tipo !== "tutor") {
  location.href = "../index.html";
} else {
  const datos = JSON.parse(localStorage.getItem(`register-tutor-${infoUsuario.correo}`)) || {};
  console.log("🧾 Datos del tutor:", datos);

  ["nombre", "telefono", "calle", "correo"].forEach(id => {
    const el = document.getElementById(id);
    if (el && datos[id]) el.value = datos[id];
  });
}

const tabDatos = document.getElementById("tab-datos");
const tabMascota = document.getElementById("tab-mascota");
const seccionDatos = document.getElementById("seccion-datos");
const seccionMascota = document.getElementById("seccion-mascota");

tabDatos.addEventListener("click", () => {
  tabDatos.classList.add("active");
  tabMascota.classList.remove("active");
  seccionDatos.classList.remove("oculto");
  seccionMascota.classList.add("oculto");
});

tabMascota.addEventListener("click", () => {
  tabDatos.classList.remove("active");
  tabMascota.classList.add("active");
  seccionDatos.classList.add("oculto");
  seccionMascota.classList.remove("oculto");
});

const form = document.getElementById("form-datos");
const btnEditar = document.getElementById("editar-perfil");
const btnGuardar = document.getElementById("guardar-cambios");
let datosOriginales = {};
let modoEdicion = false;

btnEditar.addEventListener("click", () => {
  const inputs = form.querySelectorAll("input, select");
  if (!modoEdicion) {
    datosOriginales = {};
    inputs.forEach(el => {
      datosOriginales[el.id] = el.value;
      el.disabled = false;
    });
    btnGuardar.classList.remove("oculto");
    btnEditar.textContent = "RESTABLECER";
    modoEdicion = true;
  } else {
    inputs.forEach(el => {
      el.value = datosOriginales[el.id];
      el.disabled = true;
    });
    btnGuardar.classList.add("oculto");
    btnEditar.textContent = "EDITAR PERFIL";
    modoEdicion = false;
  }
});

form.addEventListener("submit", e => {
  e.preventDefault();
  const inputs = form.querySelectorAll("input, select");
  inputs.forEach(el => el.disabled = true);
  btnGuardar.classList.add("oculto");
  btnEditar.textContent = "EDITAR PERFIL";
  modoEdicion = false;

  const updated = {
    ...JSON.parse(localStorage.getItem(`register-tutor-${infoUsuario.correo}`)),
    nombre: document.getElementById("nombre").value.trim(),
    telefono: document.getElementById("telefono").value.trim(),
    calle: document.getElementById("calle").value,
    correo: infoUsuario.correo
  };

  localStorage.setItem(`register-tutor-${infoUsuario.correo}`, JSON.stringify(updated));
  alert("Datos actualizados ✅");
});
