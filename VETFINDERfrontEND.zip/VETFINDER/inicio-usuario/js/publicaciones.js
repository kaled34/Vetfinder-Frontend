// Cargar y mostrar publicaciones de veterinarios en el inicio
document.addEventListener('DOMContentLoaded', () => {
  const cont = document.getElementById('veterinarias-container');
  const pubs = JSON.parse(localStorage.getItem('publicaciones')) || [];
  
  // Limpiar contenedor
  cont.innerHTML = '';
  
  // Si no hay publicaciones, mostrar mensaje
  if (pubs.length === 0) {
    cont.innerHTML = '<p style="text-align: center; color: #666;">No hay veterinarias disponibles en este momento.</p>';
    return;
  }
  
  // Crear tarjeta para cada veterinario
  pubs.forEach(p => {
    const card = document.createElement('div');
    card.className = 'veterinaria-card';
    
    // Determinar qué imagen usar
    const imagenSrc = p.fotoPerfil || "../imagenes/veterinario.jpg";
    
    card.innerHTML = `
      <img src="${imagenSrc}" class="vet-img" alt="${p.nombre}" onerror="this.src='../imagenes/veterinario.jpg'">
      <div class="vet-info">
        <div class="vet-nombre">${p.nombreVeterinaria || 'Veterinaria'}</div>
        <div class="vet-doctor">${p.nombre || 'Nombre no disponible'}</div>
        <div class="vet-titulo">${p.titulo || 'Médico Veterinario'}</div>
        <div class="vet-horario">${p.horario || 'Horario no especificado'}</div>
        <div class="vet-ubicacion">${p.ubicacion || 'Ubicación no especificada'}</div>
      </div>
    `;
    
    // Agregar evento de clic para ir al consultorio
    card.addEventListener('click', () => {
      if (p.correo) {
        const url = `../vet-consultorio/vet-consultorio.html?correo=${encodeURIComponent(p.correo)}`;
        window.location.href = url;
      } else {
        alert("No se encontró el correo del especialista.");
      }
    });
    
    // Agregar efecto hover
    card.addEventListener('mouseenter', () => {
      card.style.transform = 'translateY(-2px)';
      card.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    });
    
    card.addEventListener('mouseleave', () => {
      card.style.transform = 'translateY(0)';
      card.style.boxShadow = 'none';
    });

    cont.appendChild(card);
  });
});

/**
 * Función para refrescar las publicaciones (útil si se actualiza dinámicamente)
 */
function refrescarPublicaciones() {
  const event = new Event('DOMContentLoaded');
  document.dispatchEvent(event);
}

/**
 * Función para buscar veterinarias (para futuras implementaciones)
 */
function buscarVeterinarias(termino) {
  const pubs = JSON.parse(localStorage.getItem('publicaciones')) || [];
  const cont = document.getElementById('veterinarias-container');
  
  if (!termino.trim()) {
    // Si no hay término de búsqueda, mostrar todas
    refrescarPublicaciones();
    return;
  }
  
  // Filtrar publicaciones
  const resultados = pubs.filter(p => {
    const textoCompleto = `${p.nombreVeterinaria} ${p.nombre} ${p.titulo} ${p.ubicacion}`.toLowerCase();
    return textoCompleto.includes(termino.toLowerCase());
  });
  
  // Mostrar resultados
  cont.innerHTML = '';
  
  if (resultados.length === 0) {
    cont.innerHTML = `<p style="text-align: center; color: #666;">No se encontraron veterinarias que coincidan con "${termino}".</p>`;
    return;
  }
  
  resultados.forEach(p => {
    const card = document.createElement('div');
    card.className = 'veterinaria-card';
    
    const imagenSrc = p.fotoPerfil || "../imagenes/veterinario.jpg";
    
    card.innerHTML = `
      <img src="${imagenSrc}" class="vet-img" alt="${p.nombre}" onerror="this.src='../imagenes/veterinario.jpg'">
      <div class="vet-info">
        <div class="vet-nombre">${p.nombreVeterinaria || 'Veterinaria'}</div>
        <div class="vet-doctor">${p.nombre || 'Nombre no disponible'}</div>
        <div class="vet-titulo">${p.titulo || 'Médico Veterinario'}</div>
        <div class="vet-horario">${p.horario || 'Horario no especificado'}</div>
        <div class="vet-ubicacion">${p.ubicacion || 'Ubicación no especificada'}</div>
      </div>
    `;
    
    card.addEventListener('click', () => {
      if (p.correo) {
        const url = `../vet-consultorio/vet-consultorio.html?correo=${encodeURIComponent(p.correo)}`;
        window.location.href = url;
      } else {
        alert("No se encontró el correo del especialista.");
      }
    });

    cont.appendChild(card);
  });
}