const track = document.querySelector('.slider-track');
const slides = track.querySelectorAll('img');
let index = 0;

// Clonar la primera imagen al final
const clone = slides[0].cloneNode(true);
track.appendChild(clone);

const total = slides.length + 1;

function moverSlider() {
  index++;
  track.style.transition = 'transform 0.8s ease-in-out';
  track.style.transform = `translateX(-${index * 100}%)`;

  // Cuando llegamos al clon (última imagen), reiniciamos
  if (index === total - 1) {
    setTimeout(() => {
      track.style.transition = 'none';
      track.style.transform = 'translateX(0)';
      index = 0;
    }, 800); // igual a la duración del transition
  }
}

setInterval(moverSlider, 4000);
