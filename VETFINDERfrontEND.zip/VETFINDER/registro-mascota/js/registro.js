// Variables globales
let imgBase64 = "";
const form = document.getElementById("registroMascota");
const uploadArea = document.getElementById("upload-area");
const fileInput = document.getElementById("foto");
const imagePreview = document.getElementById("image-preview");
const previewImg = document.getElementById("preview-img");
const btnRemoveImage = document.getElementById("btn-remove-image");
const mensajeEstado = document.getElementById("mensaje-estado");

// Inicialización
document.addEventListener("DOMContentLoaded", () => {
  verificarAutenticacion();
  configurarSubidaImagen();
  configurarFormulario();
  configurarValidaciones();
});

/**
 * Verificar que el usuario esté logueado como tutor
 */
function verificarAutenticacion() {
  const info = JSON.parse(localStorage.getItem("ultimoUsuario"));
  if (!info || info.tipo !== "tutor") {
    alert("Debes estar logueado como tutor para registrar una mascota.");
    window.location.href = "../index.html";
    return false;
  }
  return true;
}

/**
 * Configurar funcionalidad de subida de imagen
 */
function configurarSubidaImagen() {
  // Click en área de upload
  uploadArea.addEventListener("click", () => {
    fileInput.click();
  });

  // Drag and drop
  uploadArea.addEventListener("dragover", (e) => {
    e.preventDefault();
    uploadArea.classList.add("dragover");
  });

  uploadArea.addEventListener("dragleave", () => {
    uploadArea.classList.remove("dragover");
  });

  uploadArea.addEventListener("drop", (e) => {
    e.preventDefault();
    uploadArea.classList.remove("dragover");
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      procesarImagen(files[0]);
    }
  });

  // Cambio en input file
  fileInput.addEventListener("change", function () {
    if (this.files.length > 0) {
      procesarImagen(this.files[0]);
    }
  });

  // Botón quitar imagen
  btnRemoveImage.addEventListener("click", () => {
    quitarImagen();
  });
}

/**
 * Procesar imagen seleccionada
 */
function procesarImagen(file) {
  // Validar tipo de archivo
  if (!file.type.startsWith('image/')) {
    alert('Por favor selecciona un archivo de imagen válido (JPG, PNG, GIF).');
    return;
  }

  // Validar tamaño (5MB máximo)
  if (file.size > 5 * 1024 * 1024) {
    alert('La imagen es demasiado grande. El tamaño máximo permitido es 5MB.');
    return;
  }

  // Leer archivo como base64
  const reader = new FileReader();
  reader.onload = function (e) {
    imgBase64 = e.target.result;
    mostrarPreview();
  };
  reader.onerror = function() {
    alert('Error al leer el archivo. Por favor intenta con otra imagen.');
  };
  reader.readAsDataURL(file);
}

/**
 * Mostrar preview de la imagen
 */
function mostrarPreview() {
  previewImg.src = imgBase64;
  uploadArea.style.display = 'none';
  imagePreview.style.display = 'block';
}

/**
 * Quitar imagen seleccionada
 */
function quitarImagen() {
  imgBase64 = "";
  fileInput.value = "";
  uploadArea.style.display = 'block';
  imagePreview.style.display = 'none';
}

/**
 * Configurar validaciones del formulario
 */
function configurarValidaciones() {
  // Validación de edad basada en fecha de nacimiento
  const fechaInput = document.getElementById("fecha");
  const edadInput = document.getElementById("edad");

  fechaInput.addEventListener("change", () => {
    if (fechaInput.value) {
      const fechaNacimiento = new Date(fechaInput.value);
      const hoy = new Date();
      const edadCalculada = Math.floor((hoy - fechaNacimiento) / (365.25 * 24 * 60 * 60 * 1000));
      
      if (edadCalculada >= 0 && edadCalculada <= 30) {
        edadInput.value = edadCalculada;
      }
    }
  });

  // Establecer fecha máxima como hoy
  const hoy = new Date().toISOString().split('T')[0];
  fechaInput.setAttribute('max', hoy);
}

/**
 * Configurar manejo del formulario
 */
function configurarFormulario() {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    
    if (!verificarAutenticacion()) return;
    
    // Mostrar mensaje de carga
    mostrarMensajeEstado("Guardando mascota...", true);
    
    // Simular delay para mostrar el spinner
    setTimeout(() => {
      guardarMascota();
    }, 500);
  });
}

/**
 * Guardar nueva mascota
 */
function guardarMascota() {
  try {
    // Obtener información del usuario
    const infoUsuario = JSON.parse(localStorage.getItem("ultimoUsuario"));
    
    // Validar datos del formulario
    const datosValidos = validarFormulario();
    if (!datosValidos) {
      ocultarMensajeEstado();
      return;
    }

    // Crear objeto mascota
    const nuevaMascota = {
      id: Date.now(), // ID único basado en timestamp
      nombre: document.getElementById("nombre").value.trim(),
      fecha: document.getElementById("fecha").value,
      edad: parseInt(document.getElementById("edad").value),
      sexo: form.sexo.value,
      raza: document.getElementById("raza").value.trim(),
      especie: document.getElementById("especie").value,
      imagen: imgBase64 || "",
      fechaRegistro: new Date().toISOString()
    };

    // Cargar mascotas existentes o crear array vacío
    const claveMascotas = `mascotas-${infoUsuario.correo}`;
    let mascotasExistentes = [];
    
    try {
      const mascotasGuardadas = localStorage.getItem(claveMascotas);
      if (mascotasGuardadas) {
        mascotasExistentes = JSON.parse(mascotasGuardadas);
      }
    } catch (error) {
      console.warn("Error al cargar mascotas existentes:", error);
      mascotasExistentes = [];
    }

    // Verificar que mascotasExistentes sea un array
    if (!Array.isArray(mascotasExistentes)) {
      mascotasExistentes = [];
    }

    // Agregar nueva mascota al array
    mascotasExistentes.push(nuevaMascota);

    // Guardar array actualizado
    localStorage.setItem(claveMascotas, JSON.stringify(mascotasExistentes));

    // Limpiar datos de formato antiguo si existen
    const claveAntigua = `mascota-${infoUsuario.correo}`;
    if (localStorage.getItem(claveAntigua)) {
      localStorage.removeItem(claveAntigua);
    }

    // Mostrar mensaje de éxito
    mostrarMensajeEstado("¡Mascota registrada exitosamente! 🐾", false);
    
    // Redirigir después de un momento
    setTimeout(() => {
      window.location.href = "../perfil-tutor/perfil-tutor.html?tab=mascota&nuevo=true";
    }, 1500);

  } catch (error) {
    console.error("Error al guardar mascota:", error);
    mostrarMensajeEstado("Error al guardar la mascota. Por favor intenta nuevamente.", false);
    setTimeout(() => {
      ocultarMensajeEstado();
    }, 3000);
  }
}

/**
 * Validar datos del formulario
 */
function validarFormulario() {
  const nombre = document.getElementById("nombre").value.trim();
  const fecha = document.getElementById("fecha").value;
  const edad = document.getElementById("edad").value;
  const sexo = form.sexo.value;
  const raza = document.getElementById("raza").value.trim();
  const especie = document.getElementById("especie").value;

  // Validaciones
  if (!nombre) {
    alert("El nombre de la mascota es requerido.");
    document.getElementById("nombre").focus();
    return false;
  }

  if (nombre.length < 2) {
    alert("El nombre debe tener al menos 2 caracteres.");
    document.getElementById("nombre").focus();
    return false;
  }

  if (!fecha) {
    alert("La fecha de nacimiento es requerida.");
    document.getElementById("fecha").focus();
    return false;
  }

  // Validar que la fecha no sea futura
  const fechaNacimiento = new Date(fecha);
  const hoy = new Date();
  if (fechaNacimiento > hoy) {
    alert("La fecha de nacimiento no puede ser en el futuro.");
    document.getElementById("fecha").focus();
    return false;
  }

  if (!edad || edad < 0 || edad > 30) {
    alert("La edad debe estar entre 0 y 30 años.");
    document.getElementById("edad").focus();
    return false;
  }

  if (!sexo) {
    alert("Por favor selecciona el sexo de la mascota.");
    return false;
  }

  if (!raza) {
    alert("La raza es requerida.");
    document.getElementById("raza").focus();
    return false;
  }

  if (!especie) {
    alert("Por favor selecciona la especie.");
    document.getElementById("especie").focus();
    return false;
  }

  return true;
}

/**
 * Mostrar mensaje de estado
 */
function mostrarMensajeEstado(mensaje, mostrarSpinner = false) {
  const mensajeContent = mensajeEstado.querySelector('.mensaje-content');
  const spinner = mensajeContent.querySelector('.spinner');
  const texto = mensajeContent.querySelector('p');
  
  texto.textContent = mensaje;
  spinner.style.display = mostrarSpinner ? 'block' : 'none';
  mensajeEstado.classList.remove('oculto');
}

/**
 * Ocultar mensaje de estado
 */
function ocultarMensajeEstado() {
  mensajeEstado.classList.add('oculto');
}

/**
 * Limpiar formulario
 */
function limpiarFormulario() {
  form.reset();
  quitarImagen();
}