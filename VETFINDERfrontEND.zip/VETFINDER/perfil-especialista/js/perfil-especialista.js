// ===============================================
// ARCHIVO: perfil-especialista.js - CON CATÁLOGO DE SERVICIOS
// ===============================================

// Verificar autenticación
const info = JSON.parse(localStorage.getItem("ultimoUsuario"));
if (!info || info.tipo !== "especialista") {
  alert("Debes iniciar sesión como especialista.");
  location.href = "../index.html";
}

let datos = JSON.parse(localStorage.getItem(`register-especialista-${info.correo}`)) || {};

// Variables para gestión de citas
let citas = [];
let filtroActual = 'todas';

// Mapeo de campos del formulario
const campos = {
  "nombre-clinica": "consultorio",
  "nombre-vet": "nombre",
  "cedula-vet": "cedula",
  "descripcion-vet": "descripcion",
  "ubicacion": "calle",
  "telefono": "telefono",
  "horario": "horario"
};

// Variables para el modal de imagen
let imagenSeleccionada = null;

// ===============================================
// CATÁLOGO DE SERVICIOS PREDEFINIDOS
// ===============================================

/**
 * Catálogo completo de servicios con sus precios predeterminados
 */
const CATALOGO_SERVICIOS = {
  "Baño medicado - Mini Toy": { precio: "150", categoria: "baño" },
  "Baño medicado - Chico": { precio: "200", categoria: "baño" },
  "Baño medicado - Mediano": { precio: "250", categoria: "baño" },
  "Baño medicado - Grande": { precio: "300", categoria: "baño" },
  
  "Desparacitante - 0-5 kg": { precio: "80", categoria: "desparacitante" },
  "Desparacitante - 6-10 kg": { precio: "120", categoria: "desparacitante" },
  "Desparacitante - 10-15 kg": { precio: "150", categoria: "desparacitante" },
  "Desparacitante - 15-25 kg": { precio: "180", categoria: "desparacitante" },
  
  "Estética - Mini Toy": { precio: "200", categoria: "estetica" },
  "Estética - Chico": { precio: "250", categoria: "estetica" },
  "Estética - Mediano": { precio: "300", categoria: "estetica" },
  "Estética - Grande": { precio: "350", categoria: "estetica" },
  
  "Vacuna - Mini Toy": { precio: "100", categoria: "vacuna" },
  "Vacuna - Chico": { precio: "120", categoria: "vacuna" },
  "Vacuna - Mediano": { precio: "140", categoria: "vacuna" },
  "Vacuna - Grande": { precio: "160", categoria: "vacuna" },
  
  "Consulta general": { precio: "180", categoria: "consulta" }
};

// Inicialización cuando carga la página
document.addEventListener('DOMContentLoaded', () => {
  inicializarTabs();
  cargarDatosFormulario();
  configurarBotones();
  renderServicios();
  configurarModalImagen();
  cargarImagenPerfil();
  inicializarSistemaCitas();
  inicializarCatalogoServicios();
});

/**
 * Configurar funcionalidad de tabs - ACTUALIZADA PARA INCLUIR GRÁFICAS
 */
function inicializarTabs() {
  const tabs = document.querySelectorAll(".tab");
  const sections = document.querySelectorAll(".tab-content");
  
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      sections.forEach(s => s.classList.remove("active"));
      tab.classList.add("active");
      
      // Activar sección correspondiente
      if (tab.id === "tab-consultorio") {
        document.getElementById("consultorio").classList.add("active");
      } else if (tab.id === "tab-datos") {
        document.getElementById("datos").classList.add("active");
        // Generar gráficas cuando se abre la pestaña de datos
        generarGraficasEstadisticasEspecialista(info.correo);
      } else if (tab.id === "tab-citas") {
        document.getElementById("citas").classList.add("active");
        cargarCitas(); // Cargar citas al abrir la pestaña
      }
    });
  });
}

/**
 * Cargar datos en el formulario
 */
function cargarDatosFormulario() {
  Object.entries(campos).forEach(([inputId, key]) => {
    const el = document.getElementById(inputId);
    if (el) el.value = datos[key] || "";
  });
  document.getElementById("titulo-vet").value = "Médico Veterinario Zootecnista";
}

/**
 * Configurar botones principales
 */
function configurarBotones() {
  const btnEditar = document.getElementById("editar-btn");
  const btnGuardar = document.getElementById("guardar-btn");
  const btnPublicar = document.getElementById("publicar-btn");
  let editando = false;
  let copiaOriginal = {};

  // Botón Editar/Cancelar
  btnEditar.addEventListener("click", () => {
    const inputs = document.querySelectorAll("input, textarea");
    if (!editando) {
      copiaOriginal = {};
      inputs.forEach(input => {
        copiaOriginal[input.id] = input.value;
        input.disabled = false;
      });
      btnGuardar.classList.remove("oculto");
      btnEditar.textContent = "CANCELAR";
      editando = true;
    } else {
      inputs.forEach(input => {
        input.value = copiaOriginal[input.id];
        input.disabled = true;
      });
      btnGuardar.classList.add("oculto");
      btnEditar.textContent = "EDITAR PERFIL";
      editando = false;
    }
  });

  // Botón Guardar
  btnGuardar.addEventListener("click", () => {
    // Validar servicios antes de guardar
    if (!validarServicios()) {
      if (confirm("Algunos servicios no están en el catálogo oficial. ¿Deseas continuar de todos modos?")) {
        guardarCambiosEspecialista();
      }
      return;
    }
    
    guardarCambiosEspecialista();
  });

  // Botón Publicar
  btnPublicar.addEventListener("click", () => {
    publicarPerfilEnInicio();
  });
}

/**
 * Función de guardado modificada para incluir catálogo
 */
function guardarCambiosEspecialista() {
  Object.entries(campos).forEach(([inputId, key]) => {
    const el = document.getElementById(inputId);
    if (el) datos[key] = el.value.trim();
  });
  
  // Limpiar servicios vacíos antes de guardar
  limpiarServiciosVacios();
  
  // Validar servicios del catálogo
  const serviciosCompletos = exportarServiciosCompletos();
  console.log("💾 Guardando servicios:", serviciosCompletos);
  
  localStorage.setItem(`register-especialista-${info.correo}`, JSON.stringify(datos));
  alert("Cambios guardados correctamente ✅");
  
  // Deshabilitar inputs
  document.querySelectorAll("input, textarea").forEach(input => input.disabled = true);
  document.getElementById("guardar-btn").classList.add("oculto");
  document.getElementById("editar-btn").textContent = "EDITAR PERFIL";
}

/**
 * Configurar modal de imagen
 */
function configurarModalImagen() {
  const fotoContainer = document.querySelector('.foto-container');
  const modal = document.getElementById('modal-imagen');
  const modalClose = document.getElementById('modal-close');
  const uploadArea = document.getElementById('upload-area');
  const fileInput = document.getElementById('file-input');
  const imagePreview = document.getElementById('image-preview');
  const previewImg = document.getElementById('preview-img');
  const btnChange = document.getElementById('btn-change');
  const btnCancelar = document.getElementById('btn-cancelar');
  const btnGuardarImagen = document.getElementById('btn-guardar-imagen');

  // Abrir modal al hacer clic en la foto
  fotoContainer.addEventListener('click', () => {
    modal.classList.add('active');
    resetearModal();
  });

  // Cerrar modal
  const cerrarModal = () => {
    modal.classList.remove('active');
    resetearModal();
  };

  modalClose.addEventListener('click', cerrarModal);
  btnCancelar.addEventListener('click', cerrarModal);

  // Cerrar modal al hacer clic en el overlay
  modal.addEventListener('click', (e) => {
    if (e.target === modal) cerrarModal();
  });

  // Área de arrastrar y soltar
  uploadArea.addEventListener('click', () => fileInput.click());
  
  uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('dragover');
  });

  uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('dragover');
  });

  uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      procesarArchivo(files[0]);
    }
  });

  // Input file
  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      procesarArchivo(e.target.files[0]);
    }
  });

  // Botón cambiar imagen
  btnChange.addEventListener('click', () => {
    fileInput.click();
  });

  // Botón guardar imagen
  btnGuardarImagen.addEventListener('click', () => {
    if (imagenSeleccionada) {
      guardarImagenPerfil(imagenSeleccionada);
      cerrarModal();
    }
  });

  function procesarArchivo(file) {
    if (!file.type.startsWith('image/')) {
      alert('Por favor selecciona un archivo de imagen válido.');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('La imagen es demasiado grande. Máximo 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      imagenSeleccionada = e.target.result;
      mostrarPreview(imagenSeleccionada);
    };
    reader.readAsDataURL(file);
  }

  function mostrarPreview(imagenBase64) {
    previewImg.src = imagenBase64;
    uploadArea.style.display = 'none';
    imagePreview.style.display = 'block';
    btnGuardarImagen.disabled = false;
  }

  function resetearModal() {
    uploadArea.style.display = 'block';
    imagePreview.style.display = 'none';
    fileInput.value = '';
    imagenSeleccionada = null;
    btnGuardarImagen.disabled = true;
  }
}

/**
 * Guardar imagen de perfil en localStorage
 */
function guardarImagenPerfil(imagenBase64) {
  datos.fotoPerfil = imagenBase64;
  localStorage.setItem(`register-especialista-${info.correo}`, JSON.stringify(datos));
  
  // Actualizar imagen en la vista
  document.getElementById('foto-vet').src = imagenBase64;
  
  alert('Imagen de perfil guardada correctamente ✅');
}

/**
 * Cargar imagen de perfil guardada
 */
function cargarImagenPerfil() {
  if (datos.fotoPerfil) {
    document.getElementById('foto-vet').src = datos.fotoPerfil;
  }
}

// ===============================================
// SISTEMA DE SERVICIOS CON CATÁLOGO
// ===============================================

const contenedorServicios = document.getElementById("servicios-container");
const btnAgregarServicio = document.getElementById("agregar-servicio");

/**
 * Renderizar servicios con catálogo desplegable - VERSIÓN COMPLETA
 */
function renderServicios() {
  contenedorServicios.innerHTML = "";
  
  (datos.servicios || []).forEach((serv, i) => {
    const fila = document.createElement("div");
    fila.className = "serv-fila";
    
    // Crear select para el catálogo de servicios
    const selectServicio = document.createElement("select");
    selectServicio.className = "select-servicio";
    
    // Opción por defecto
    const optionDefault = document.createElement("option");
    optionDefault.value = "";
    optionDefault.textContent = "Selecciona un servicio";
    selectServicio.appendChild(optionDefault);
    
    // Agregar opciones del catálogo organizadas por categoría
    const categorias = {
      "baño": "🛁 Baño Medicado",
      "desparacitante": "💊 Desparacitante", 
      "estetica": "✂️ Estética",
      "vacuna": "💉 Vacunas",
      "consulta": "🩺 Consultas"
    };
    
    Object.entries(categorias).forEach(([categoria, titulo]) => {
      // Crear grupo de opciones
      const optgroup = document.createElement("optgroup");
      optgroup.label = titulo;
      
      // Agregar servicios de esta categoría
      Object.entries(CATALOGO_SERVICIOS)
        .filter(([_, info]) => info.categoria === categoria)
        .forEach(([nombreServicio, info]) => {
          const option = document.createElement("option");
          option.value = nombreServicio;
          option.textContent = `${nombreServicio} - $${info.precio}`;
          option.dataset.precio = info.precio;
          option.dataset.categoria = info.categoria;
          
          // Seleccionar si coincide con el servicio actual
          if (serv.nombre === nombreServicio) {
            option.selected = true;
          }
          
          optgroup.appendChild(option);
        });
      
      selectServicio.appendChild(optgroup);
    });
    
    // Evento para actualizar precio automáticamente
    selectServicio.onchange = () => {
      const servicioSeleccionado = selectServicio.value;
      if (servicioSeleccionado && CATALOGO_SERVICIOS[servicioSeleccionado]) {
        // Actualizar nombre del servicio
        datos.servicios[i].nombre = servicioSeleccionado;
        
        // Actualizar precio automáticamente
        const precioSugerido = CATALOGO_SERVICIOS[servicioSeleccionado].precio;
        datos.servicios[i].precio = precioSugerido;
        inputPrecio.value = precioSugerido;
        inputPrecio.classList.add("precio-sugerido");
        
        // Efectos visuales
        selectServicio.classList.add("valido");
        inputPrecio.classList.add("valido");
        
        // Guardar cambios automáticamente
        localStorage.setItem(`register-especialista-${info.correo}`, JSON.stringify(datos));
        
        console.log(`✅ Servicio actualizado: ${servicioSeleccionado} - $${precioSugerido}`);
      } else {
        // Si no hay selección, limpiar
        datos.servicios[i].nombre = "";
        datos.servicios[i].precio = "";
        inputPrecio.value = "";
        inputPrecio.classList.remove("precio-sugerido");
        selectServicio.classList.remove("valido");
        inputPrecio.classList.remove("valido");
      }
    };
    
    // Input para el precio (editable pero con valor sugerido)
    const inputPrecio = document.createElement("input");
    inputPrecio.type = "number";
    inputPrecio.value = serv.precio || "";
    inputPrecio.placeholder = "Precio";
    inputPrecio.className = "input-precio";
    inputPrecio.min = "0";
    inputPrecio.step = "10";
    
    // Marcar como precio sugerido si coincide con el catálogo
    if (serv.nombre && CATALOGO_SERVICIOS[serv.nombre] && 
        serv.precio === CATALOGO_SERVICIOS[serv.nombre].precio) {
      inputPrecio.classList.add("precio-sugerido");
    }
    
    inputPrecio.oninput = () => {
      datos.servicios[i].precio = inputPrecio.value;
      
      // Remover indicador de precio sugerido si se modifica
      inputPrecio.classList.remove("precio-sugerido");
      
      // Validación visual
      if (inputPrecio.value && parseFloat(inputPrecio.value) > 0) {
        inputPrecio.classList.add("valido");
        inputPrecio.classList.remove("invalido");
      } else {
        inputPrecio.classList.remove("valido");
        inputPrecio.classList.add("invalido");
      }
    };
    
    // Botón eliminar con confirmación
    const btnEliminar = document.createElement("button");
    btnEliminar.innerHTML = "×";
    btnEliminar.className = "btn-eliminar-servicio";
    btnEliminar.type = "button";
    btnEliminar.title = "Eliminar servicio";
    btnEliminar.onclick = () => {
      if (confirm(`¿Eliminar el servicio "${serv.nombre || 'sin nombre'}"?`)) {
        eliminarServicio(i);
      }
    };
    
    // Ensamblar la fila
    fila.appendChild(selectServicio);
    fila.appendChild(inputPrecio);
    fila.appendChild(btnEliminar);
    
    // Agregar clase de animación para servicios nuevos
    if (serv.esNuevo) {
      fila.classList.add("nuevo");
      delete datos.servicios[i].esNuevo;
    }
    
    contenedorServicios.appendChild(fila);
  });
  
  // Agregar mensaje informativo si no hay servicios
  if (!datos.servicios || datos.servicios.length === 0) {
    const mensajeInfo = document.createElement("div");
    mensajeInfo.className = "catalogo-info";
    mensajeInfo.innerHTML = `
      <span>Agrega servicios de nuestro catálogo oficial con precios sugeridos.</span>
    `;
    contenedorServicios.appendChild(mensajeInfo);
  }
}

function eliminarServicio(indice) {
  datos.servicios.splice(indice, 1);
  localStorage.setItem(`register-especialista-${info.correo}`, JSON.stringify(datos));
  renderServicios();
  alert("Servicio eliminado correctamente ✅");
}

function limpiarServiciosVacios() {
  if (!datos.servicios) return;
  
  datos.servicios = datos.servicios.filter(servicio => {
    // Mantener solo servicios que tengan nombre del catálogo y precio
    return servicio.nombre && 
           servicio.nombre.trim() !== '' && 
           CATALOGO_SERVICIOS[servicio.nombre] &&
           servicio.precio && 
           servicio.precio.trim() !== '' &&
           parseFloat(servicio.precio) > 0;
  });
  
  renderServicios();
}

// Agregar servicio con marca de nuevo
btnAgregarServicio.addEventListener("click", () => {
  if (!datos.servicios) datos.servicios = [];
  datos.servicios.push({ nombre: "", precio: "", esNuevo: true });
  renderServicios();
});

/**
 * Función para validar servicios antes de guardar
 */
function validarServicios() {
  if (!datos.servicios) return true;
  
  const serviciosInvalidos = datos.servicios.filter(servicio => {
    // Verificar que el servicio esté en el catálogo
    return servicio.nombre && !CATALOGO_SERVICIOS[servicio.nombre];
  });
  
  if (serviciosInvalidos.length > 0) {
    console.warn("Servicios no válidos encontrados:", serviciosInvalidos);
    return false;
  }
  
  return true;
}

/**
 * Función para exportar servicios con información completa
 */
function exportarServiciosCompletos() {
  if (!datos.servicios) return [];
  
  return datos.servicios.map(servicio => {
    const infoCompleta = CATALOGO_SERVICIOS[servicio.nombre];
    return {
      nombre: servicio.nombre,
      precio: servicio.precio,
      categoria: infoCompleta ? infoCompleta.categoria : 'sin_categoria',
      precioSugerido: infoCompleta ? infoCompleta.precio : servicio.precio
    };
  });
}

/**
 * Inicializar el sistema de catálogo
 */
function inicializarCatalogoServicios() {
  console.log("📋 Catálogo de servicios inicializado");
  console.log("📊 Servicios disponibles:", Object.keys(CATALOGO_SERVICIOS).length);
  
  // Validar servicios existentes
  if (datos.servicios && datos.servicios.length > 0) {
    const serviciosValidos = validarServicios();
    if (!serviciosValidos) {
      console.warn("⚠️ Algunos servicios no están en el catálogo y podrían necesitar actualización");
    }
  }
}

/**
 * Publicar perfil en inicio
 */
function publicarPerfilEnInicio() {
  const serviciosValidos = (datos.servicios || []).filter(s => 
    s.nombre && s.nombre.trim() !== '' && s.precio && s.precio.trim() !== ''
  );
  
  const perfil = {
    correo: info.correo,
    nombre: document.getElementById('nombre-vet').value.trim(),
    nombreVeterinaria: document.getElementById('nombre-clinica').value.trim(),
    titulo: document.getElementById('titulo-vet').value.trim(),
    descripcion: document.getElementById('descripcion-vet').value.trim(),
    ubicacion: document.getElementById('ubicacion').value.trim(),
    telefono: document.getElementById('telefono').value.trim(),
    horario: document.getElementById('horario').value.trim(),
    servicios: serviciosValidos,
    fotoPerfil: datos.fotoPerfil || null
  };
  
  let pubs = JSON.parse(localStorage.getItem('publicaciones')) || [];
  const idx = pubs.findIndex(p => p.correo === perfil.correo);
  idx >= 0 ? pubs[idx] = perfil : pubs.push(perfil);
  localStorage.setItem('publicaciones', JSON.stringify(pubs));
  alert('Perfil publicado en inicio con éxito.');
}

// =============== SISTEMA DE GESTIÓN DE CITAS ===============

/**
 * Inicializar sistema de citas
 */
function inicializarSistemaCitas() {
  configurarFiltrosCitas();
  configurarLimpiarBandejaEspecialista();
  cargarCitas();
}

/**
 * Configurar filtros de citas
 */
function configurarFiltrosCitas() {
  const filtros = document.querySelectorAll('.filtro-btn');
  
  filtros.forEach(filtro => {
    filtro.addEventListener('click', () => {
      // Actualizar filtro activo
      filtros.forEach(f => f.classList.remove('active'));
      filtro.classList.add('active');
      
      // Actualizar filtro actual
      if (filtro.id === 'filtro-todas') filtroActual = 'todas';
      else if (filtro.id === 'filtro-pendientes') filtroActual = 'pendiente';
      else if (filtro.id === 'filtro-aceptadas') filtroActual = 'aceptada';
      else if (filtro.id === 'filtro-rechazadas') filtroActual = 'rechazada';
      
      // Re-renderizar citas
      renderizarCitas();
    });
  });
}

/**
 * Cargar citas del especialista
 */
function cargarCitas() {
  const citasGuardadas = localStorage.getItem(`citas-${info.correo}`);
  citas = citasGuardadas ? JSON.parse(citasGuardadas) : [];
  
  actualizarEstadisticas();
  renderizarCitas();
}

/**
 * Actualizar estadísticas de citas
 */
function actualizarEstadisticas() {
  const pendientes = citas.filter(c => c.estado === 'pendiente').length;
  const aceptadas = citas.filter(c => c.estado === 'aceptada').length;
  const rechazadas = citas.filter(c => c.estado === 'rechazada').length;
  
  document.getElementById('stat-pendientes').textContent = `${pendientes} Pendientes`;
  document.getElementById('stat-aceptadas').textContent = `${aceptadas} Aceptadas`;
  document.getElementById('stat-rechazadas').textContent = `${rechazadas} Rechazadas`;
}

/**
 * Renderizar lista de citas
 */
function renderizarCitas() {
  const container = document.getElementById('citas-container');
  const vacio = document.getElementById('citas-vacio');
  
  // Filtrar citas según filtro actual
  let citasFiltradas = citas;
  if (filtroActual !== 'todas') {
    citasFiltradas = citas.filter(c => c.estado === filtroActual);
  }
  
  // Ordenar por fecha de creación (más recientes primero)
  citasFiltradas.sort((a, b) => new Date(b.fechaCreacion) - new Date(a.fechaCreacion));
  
  if (citasFiltradas.length === 0) {
    container.classList.add('oculto');
    vacio.classList.remove('oculto');
    return;
  }
  
  container.classList.remove('oculto');
  vacio.classList.add('oculto');
  
  container.innerHTML = '';
  
  citasFiltradas.forEach(cita => {
    const citaCard = crearTarjetaCita(cita);
    container.appendChild(citaCard);
  });
}

/**
 * Crear tarjeta de cita
 */
function crearTarjetaCita(cita) {
  const card = document.createElement('div');
  card.className = `cita-card ${cita.estado}`;
  
  card.innerHTML = `
    <div class="cita-header">
      <div class="cita-info-principal">
        <div class="cita-tutor">${cita.nombreTutor}</div>
        <div class="cita-servicio">${cita.servicio} - $${cita.precio}</div>
      </div>
      <span class="cita-estado ${cita.estado}">${obtenerTextoEstado(cita.estado)}</span>
    </div>
    
    <div class="cita-detalles">
      <div class="cita-detalle">
        <span class="cita-detalle-icono">📅</span>
        <span class="cita-detalle-texto">Fecha:</span>
        <span class="cita-detalle-valor">${formatearFecha(cita.fecha)}</span>
      </div>
      <div class="cita-detalle">
        <span class="cita-detalle-icono">🕒</span>
        <span class="cita-detalle-texto">Hora:</span>
        <span class="cita-detalle-valor">${cita.horario}</span>
      </div>
      <div class="cita-detalle">
        <span class="cita-detalle-icono">📧</span>
        <span class="cita-detalle-texto">Contacto:</span>
        <span class="cita-detalle-valor">${cita.tutorCorreo}</span>
      </div>
    </div>
    
    <div class="cita-motivo">
      <span class="cita-motivo-label">Motivo de la consulta:</span>
      <div class="cita-motivo-texto">${cita.motivo}</div>
    </div>
    
    <div class="cita-acciones">
      ${cita.estado === 'pendiente' ? `
        <button class="btn-cita btn-aceptar" onclick="gestionarCita('${cita.id}', 'aceptada')">
          ✅ Aceptar
        </button>
        <button class="btn-cita btn-rechazar" onclick="gestionarCita('${cita.id}', 'rechazada')">
          ❌ Rechazar
        </button>
      ` : ''}
    </div>
    
    <div class="cita-timestamp">
      Recibida: ${formatearTimestamp(cita.fechaCreacion)}
      ${cita.fechaRespuesta ? `• Respondida: ${formatearTimestamp(cita.fechaRespuesta)}` : ''}
    </div>
  `;
  
  return card;
}

/**
 * Gestionar cita (aceptar/rechazar) - ACTUALIZADA CON REGENERACIÓN DE GRÁFICAS
 */
function gestionarCita(citaId, nuevoEstado) {
  const accion = nuevoEstado === 'aceptada' ? 'aceptar' : 'rechazar';
  
  if (!confirm(`¿Estás seguro de ${accion} esta cita?`)) {
    return;
  }
  
  // Encontrar la cita
  const indiceCita = citas.findIndex(c => c.id === citaId);
  if (indiceCita === -1) {
    alert('Error: Cita no encontrada');
    return;
  }
  
  // Actualizar estado
  citas[indiceCita].estado = nuevoEstado;
  citas[indiceCita].fechaRespuesta = new Date().toISOString();
  
  // Guardar cambios
  localStorage.setItem(`citas-${info.correo}`, JSON.stringify(citas));
  
  // Actualizar vista del tutor también
  actualizarCitaTutor(citas[indiceCita]);
  
  // Actualizar vista
  actualizarEstadisticas();
  renderizarCitas();
  
  // Regenerar gráficas si está en la pestaña de datos
  const tabDatos = document.getElementById('tab-datos');
  if (tabDatos && tabDatos.classList.contains('active')) {
    generarGraficasEstadisticasEspecialista(info.correo);
  }
  
  alert(`Cita ${nuevoEstado} correctamente ✅`);
}

/**
 * Actualizar cita en la vista del tutor
 */
function actualizarCitaTutor(cita) {
  const citasTutor = JSON.parse(localStorage.getItem(`citas-tutor-${cita.tutorCorreo}`)) || [];
  const indiceCitaTutor = citasTutor.findIndex(c => c.id === cita.id);
  
  if (indiceCitaTutor !== -1) {
    citasTutor[indiceCitaTutor] = { ...cita };
    localStorage.setItem(`citas-tutor-${cita.tutorCorreo}`, JSON.stringify(citasTutor));
  }
}

/**
 * Funciones auxiliares
 */
function obtenerTextoEstado(estado) {
  const estados = {
    'pendiente': 'Pendiente',
    'aceptada': 'Aceptada',
    'rechazada': 'Rechazada'
  };
  return estados[estado] || estado;
}

function formatearFecha(fecha) {
  const date = new Date(fecha);
  return date.toLocaleDateString('es-ES', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

function formatearTimestamp(timestamp) {
  const date = new Date(timestamp);
  return date.toLocaleString('es-ES', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

/**
 * Configurar botón limpiar bandeja del especialista
 */
function configurarLimpiarBandejaEspecialista() {
  const btnLimpiar = document.getElementById('btn-limpiar-bandeja-especialista');
  
  if (btnLimpiar) {
    btnLimpiar.addEventListener('click', () => {
      limpiarBandejaEspecialista();
    });
  }
}

/**
 * Limpiar bandeja del especialista - SOLO ELIMINA CITAS RECHAZADAS
 */
function limpiarBandejaEspecialista() {
  // Solo filtrar citas rechazadas para eliminar
  const citasAEliminar = citas.filter(c => c.estado === 'rechazada');
  
  if (citasAEliminar.length === 0) {
    alert('No hay citas rechazadas para eliminar.');
    return;
  }
  
  const mensaje = `¿Estás seguro de eliminar ${citasAEliminar.length} cita(s) rechazada(s)?\n\nLas citas pendientes y aceptadas se mantendrán para preservar las estadísticas.`;
  
  if (confirm(mensaje)) {
    // Mantener citas pendientes Y aceptadas (eliminar solo rechazadas)
    citas = citas.filter(c => c.estado === 'pendiente' || c.estado === 'aceptada');
    
    // Guardar cambios
    localStorage.setItem(`citas-${info.correo}`, JSON.stringify(citas));
    
    // Actualizar vista
    actualizarEstadisticas();
    renderizarCitas();
    
    // Regenerar gráficas si está en la pestaña de datos
    const tabDatos = document.getElementById('tab-datos');
    if (tabDatos && tabDatos.classList.contains('active')) {
      generarGraficasEstadisticasEspecialista(info.correo);
    }
    
    alert(`Bandeja limpiada correctamente ✅\n${citasAEliminar.length} cita(s) rechazada(s) eliminada(s)\nCitas aceptadas preservadas para las estadísticas.`);
  }
}

// =============== SISTEMA DE GRÁFICAS PARA ESPECIALISTA ===============

/**
 * Generar gráficas de estadísticas para el especialista
 */
function generarGraficasEstadisticasEspecialista(correoEspecialista) {
  console.log("📊 [ESPECIALISTA] Generando gráficas para:", correoEspecialista);
  
  // Obtener citas del especialista
  const citasEspecialista = JSON.parse(localStorage.getItem(`citas-${correoEspecialista}`)) || [];
  
  // Filtrar solo citas aceptadas
  const citasAceptadas = citasEspecialista.filter(cita => cita.estado === 'aceptada');
  
  console.log("✅ [ESPECIALISTA] Citas aceptadas encontradas:", citasAceptadas.length);
  
  if (citasAceptadas.length === 0) {
    mostrarGraficasVaciasEspecialista();
    return;
  }
  
  // Procesar datos para las gráficas
  const datosHorarios = procesarDatosHorariosEspecialista(citasAceptadas);
  const datosServicios = procesarDatosServiciosEspecialista(citasAceptadas);
  
  // Generar las gráficas
  generarGraficaHorariosEspecialista(datosHorarios);
  generarGraficaServiciosEspecialista(datosServicios);
}

/**
 * Procesar datos de horarios para especialista
 */
function procesarDatosHorariosEspecialista(citasAceptadas) {
  const conteoHorarios = {};
  
  citasAceptadas.forEach(cita => {
    const horario = cita.horario;
    if (horario) {
      // Agrupar por rangos de hora
      const hora = horario.split(':')[0];
      const rango = `${hora}h`;
      
      conteoHorarios[rango] = (conteoHorarios[rango] || 0) + 1;
    }
  });
  
  // Convertir a array y ordenar
  const datosOrdenados = Object.entries(conteoHorarios)
    .map(([horario, cantidad]) => ({ horario, cantidad }))
    .sort((a, b) => {
      // Ordenar por hora
      const horaA = parseInt(a.horario.replace('h', ''));
      const horaB = parseInt(b.horario.replace('h', ''));
      return horaA - horaB;
    });
  
  console.log("⏰ [ESPECIALISTA] Datos de horarios procesados:", datosOrdenados);
  return datosOrdenados;
}

/**
 * Procesar datos de servicios para especialista
 */
function procesarDatosServiciosEspecialista(citasAceptadas) {
  const conteoServicios = {};
  
  citasAceptadas.forEach(cita => {
    const servicio = cita.servicio;
    if (servicio) {
      conteoServicios[servicio] = (conteoServicios[servicio] || 0) + 1;
    }
  });
  
  // Convertir a array y ordenar por cantidad (mayor a menor)
  const datosOrdenados = Object.entries(conteoServicios)
    .map(([servicio, cantidad]) => ({ servicio, cantidad }))
    .sort((a, b) => b.cantidad - a.cantidad)
    .slice(0, 5); // Tomar solo los top 5
  
  console.log("🔬 [ESPECIALISTA] Datos de servicios procesados:", datosOrdenados);
  return datosOrdenados;
}

/**
 * Generar gráfica de horarios para especialista
 */
function generarGraficaHorariosEspecialista(datosHorarios) {
  // Encontrar o crear contenedor después de la sección de servicios
  let container = document.querySelector('.estadisticas-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'estadisticas-container';
    
    // Buscar el contenedor de servicios en la pestaña de datos
    const datosSection = document.getElementById('datos');
    if (datosSection) {
      datosSection.appendChild(container);
    }
  }
  
  // Limpiar contenedor
  container.innerHTML = '';
  
  // Crear tarjeta de horarios
  const cardHorarios = document.createElement('div');
  cardHorarios.className = 'estadistica-card';
  
  if (datosHorarios.length === 0) {
    cardHorarios.innerHTML = `
      <h4>HORARIOS MÁS CONCURRIDOS</h4>
      <div class="estadisticas-vacio">
        <div class="icono-vacio">🕒</div>
        <p>No hay datos de horarios</p>
      </div>
    `;
  } else {
    const maxCantidad = Math.max(...datosHorarios.map(d => d.cantidad));
    
    // Generar marcas del eje Y
    const marcasY = [];
    for (let i = maxCantidad; i >= 0; i -= Math.ceil(maxCantidad / 4)) {
      if (i >= 0) marcasY.push(i);
    }
    
    cardHorarios.innerHTML = `
      <h4>HORARIOS MÁS CONCURRIDOS</h4>
      <div class="grafica-container">
        <div class="eje-y">
          ${marcasY.map(marca => `<div class="marca-y">${marca}</div>`).join('')}
        </div>
        <div class="grafica-barras">
          ${datosHorarios.map(dato => {
            const altura = (dato.cantidad / maxCantidad) * 100;
            const esDestacada = dato.cantidad === maxCantidad;
            return `
              <div class="barra-container">
                <div class="barra ${esDestacada ? 'destacada' : ''}" 
                     style="height: ${altura}%" 
                     data-value="${dato.cantidad}">
                </div>
                <div class="etiqueta">${dato.horario}</div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }
  
  container.appendChild(cardHorarios);
}

/**
 * Generar gráfica de servicios para especialista
 */
function generarGraficaServiciosEspecialista(datosServicios) {
  const container = document.querySelector('.estadisticas-container');
  
  // Crear tarjeta de servicios
  const cardServicios = document.createElement('div');
  cardServicios.className = 'estadistica-card';
  
  if (datosServicios.length === 0) {
    cardServicios.innerHTML = `
      <h4>SERVICIOS MÁS SOLICITADOS</h4>
      <div class="estadisticas-vacio">
        <div class="icono-vacio">🔬</div>
        <p>No hay datos de servicios</p>
      </div>
    `;
  } else {
    const maxCantidad = Math.max(...datosServicios.map(d => d.cantidad));
    
    // Generar marcas del eje Y
    const marcasY = [];
    for (let i = maxCantidad; i >= 0; i -= Math.ceil(maxCantidad / 4)) {
      if (i >= 0) marcasY.push(i);
    }
    
    cardServicios.innerHTML = `
      <h4>SERVICIOS MÁS SOLICITADOS</h4>
      <div class="grafica-container">
        <div class="eje-y">
          ${marcasY.map(marca => `<div class="marca-y">${marca}</div>`).join('')}
        </div>
        <div class="grafica-barras">
          ${datosServicios.map(dato => {
            const altura = (dato.cantidad / maxCantidad) * 100;
            const esDestacada = dato.cantidad === maxCantidad;
            // Acortar nombres largos de servicios
            const nombreCorto = dato.servicio.length > 12 
              ? dato.servicio.substring(0, 10) + '...' 
              : dato.servicio;
            return `
              <div class="barra-container">
                <div class="barra ${esDestacada ? 'destacada' : ''}" 
                     style="height: ${altura}%" 
                     data-value="${dato.cantidad}"
                     title="${dato.servicio}: ${dato.cantidad} citas">
                </div>
                <div class="etiqueta" title="${dato.servicio}">${nombreCorto}</div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }
  
  container.appendChild(cardServicios);
}

/**
 * Mostrar gráficas vacías para especialista
 */
function mostrarGraficasVaciasEspecialista() {
  let container = document.querySelector('.estadisticas-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'estadisticas-container';
    
    const datosSection = document.getElementById('datos');
    if (datosSection) {
      datosSection.appendChild(container);
    }
  }
  
  container.innerHTML = `
    <div class="estadistica-card">
      <h4>HORARIOS MÁS CONCURRIDOS</h4>
      <div class="estadisticas-vacio">
        <div class="icono-vacio">🕒</div>
        <p>No hay citas aceptadas aún</p>
      </div>
    </div>
    <div class="estadistica-card">
      <h4>SERVICIOS MÁS SOLICITADOS</h4>
      <div class="estadisticas-vacio">
        <div class="icono-vacio">🔬</div>
        <p>No hay citas aceptadas aún</p>
      </div>
    </div>
  `;
  
  console.log("📊 [ESPECIALISTA] Mostrando gráficas vacías - No hay citas aceptadas");
}